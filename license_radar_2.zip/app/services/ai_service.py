import json
import requests
from datetime import datetime
from app.models import License, Clause, Component, Application
from app import Session
from config import Config
import logging

logger = logging.getLogger(__name__)

def get_runtime_settings():
    """Get settings from database at runtime.
    
    Priority order:
    1. Database settings (Admin Panel) - HIGHEST PRIORITY
    2. Environment variables - as fallback
    """
    import os
    settings = {}
    
    # First try environment variables
    env_key = os.environ.get('OPENROUTER_API_KEY')
    if env_key:
        settings['openrouter_api_key'] = env_key
    
    env_model = os.environ.get('OPENROUTER_MODEL')
    if env_model:
        settings['openrouter_model'] = env_model
    
    env_ollama = os.environ.get('OLLAMA_BASE_URL')
    if env_ollama:
        settings['ollama_url'] = env_ollama
        
    env_ollama_model = os.environ.get('OLLAMA_MODEL')
    if env_ollama_model:
        settings['ollama_model'] = env_ollama_model
    
    # Database settings override environment variables
    try:
        from app.models import Settings
        from app import Session
        session = Session()
        
        db_settings = session.query(Settings).all()
        for s in db_settings:
            if s.value:
                settings[s.key] = s.value
        
        session.close()
    except Exception as e:
        logger.warning(f"Could not load settings from database: {e}")
    
    return settings

SYSTEM_PROMPT = """You are a software license analyst. Extract all legally significant clauses
from the license text provided. Return ONLY valid JSON, no explanation, no markdown.

Analyze this license text and extract clauses as JSON:

{license_text}

Return this exact JSON structure:
{{
  "license_name": "string",
  "spdx_id": "string or null",
  "clauses": [
    {{
      "clause_type": "one of: copyleft|network_use|patent|commercial_restriction|trademark|attribution|warranty_liability|export_control|data_processing",
      "clause_title": "short title",
      "clause_text": "exact excerpt from license",
      "risk_level": "one of: critical|warning|info",
      "deployment_scope": "one of: internal|external|both",
      "ai_explanation": "plain English explanation of what this means for a bank"
    }}
  ]
}}"""

def check_ollama_available():
    """Check if Ollama service is running."""
    try:
        response = requests.get(
            f"{Config.OLLAMA_BASE_URL}/api/tags",
            timeout=5
        )
        return response.status_code == 200
    except Exception as e:
        logger.warning(f"Ollama availability check failed: {e}")
        return False

def check_openrouter_available():
    """Check if OpenRouter API is configured and available."""
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key')
    if not api_key:
        return False
    try:
        response = requests.get(
            f"{Config.OPENROUTER_BASE_URL}/models",
            headers={'Authorization': f'Bearer {api_key}'},
            timeout=5
        )
        return response.status_code == 200
    except Exception as e:
        logger.warning(f"OpenRouter availability check failed: {e}")
        return False

def analyze_with_openrouter(license_text):
    """Analyze license using OpenRouter API."""
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key')
    
    if not api_key:
        return None, 'OpenRouter API key not configured. Please go to Admin > Settings and enter your API key.'
    
    model = settings.get('openrouter_model', 'anthropic/claude-3-haiku')
    
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:5000',
            'X-Title': 'License Radar'
        }
        
        payload = {
            'model': model,
            'messages': [
                {
                    'role': 'system',
                    'content': SYSTEM_PROMPT.format(license_text='')
                },
                {
                    'role': 'user',
                    'content': f"Analyze this license text and extract clauses as JSON:\n\n{license_text[:8000]}"
                }
            ],
            'temperature': 0.1,
            'max_tokens': 2000
        }
        
        response = requests.post(
            f"{Config.OPENROUTER_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
            timeout=Config.OLLAMA_TIMEOUT_SECONDS
        )
        
        if response.status_code != 200:
            return None, f'OpenRouter returned status {response.status_code}: {response.text}'
        
        result = response.json()
        response_text = result['choices'][0]['message']['content']
        
        json_start = response_text.find('{')
        json_end = response_text.rfind('}') + 1
        
        if json_start == -1 or json_end == 0:
            return None, 'Could not parse JSON from OpenRouter response'
        
        json_str = response_text[json_start:json_end]
        data = json.loads(json_str)
        return data, None
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse error from OpenRouter: {e}")
        return None, f'Failed to parse OpenRouter response: {str(e)}'
    except requests.exceptions.Timeout:
        return None, 'Analysis timed out'
    except Exception as e:
        logger.error(f"OpenRouter analysis error: {e}")
        return None, str(e)

def analyze_license(license_id, provider=None):
    """Analyze a license using OpenRouter (default) or Ollama."""
    session = Session()
    license = session.query(License).get(license_id)
    
    if not license:
        session.close()
        return {'success': False, 'error': 'License not found'}
    
    # Determine provider: default to OpenRouter if API key is set, else Ollama
    if provider is None:
        provider = 'openrouter' if Config.OPENROUTER_API_KEY else 'ollama'
    
    data = None
    error = None
    
    if provider == 'openrouter':
        data, error = analyze_with_openrouter(license.license_text[:8000])
    else:
        # Fallback to Ollama
        if not check_ollama_available():
            session.close()
            return {
                'success': False, 
                'error': 'Ollama service is not available. Please ensure Ollama is running.',
                'provider': 'ollama'
            }
        data, error = analyze_with_ollama(license.license_text[:8000])
    
    if error:
        license.analysis_status = 'failed'
        session.commit()
        session.close()
        return {'success': False, 'error': error, 'provider': provider}
    
    # Save results
    license.license_name = data.get('license_name', license.license_name)
    license.spdx_id = data.get('spdx_id')
    license.analyzed_at = datetime.utcnow()
    
    for clause_data in data.get('clauses', []):
        clause = Clause(
            license_id=license.id,
            clause_type=clause_data.get('clause_type'),
            clause_title=clause_data.get('clause_title'),
            clause_text=clause_data.get('clause_text'),
            risk_level=clause_data.get('risk_level', 'info'),
            deployment_scope=clause_data.get('deployment_scope', 'both'),
            ai_explanation=clause_data.get('ai_explanation')
        )
        session.add(clause)
    
    session.commit()
    session.close()
    
    from app.services.rag_service import embed_license
    embed_license(license_id)
    
    return {'success': True, 'clauses_extracted': len(data.get('clauses', [])), 'provider': provider}

def analyze_with_ollama(license_text):
    """Analyze license using Ollama API."""
    try:
        prompt = SYSTEM_PROMPT.format(license_text=license_text[:8000])
        
        payload = {
            'model': Config.OLLAMA_MODEL,
            'prompt': prompt,
            'stream': False,
            'options': {
                'temperature': 0.1,
                'num_predict': 2000
            }
        }
        
        response = requests.post(
            f"{Config.OLLAMA_BASE_URL}/api/generate",
            json=payload,
            timeout=Config.OLLAMA_TIMEOUT_SECONDS
        )
        
        if response.status_code != 200:
            return None, f'Ollama returned status {response.status_code}'
        
        result = response.json()
        response_text = result.get('response', '')
        
        json_start = response_text.find('{')
        json_end = response_text.rfind('}') + 1
        
        if json_start == -1 or json_end == 0:
            return None, 'Could not parse JSON from Ollama response'
        
        json_str = response_text[json_start:json_end]
        data = json.loads(json_str)
        return data, None
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse error from Ollama: {e}")
        return None, f'Failed to parse Ollama response: {str(e)}'
    except requests.exceptions.Timeout:
        return None, 'Analysis timed out'
    except Exception as e:
        logger.error(f"Ollama analysis error: {e}")
        return None, str(e)

def get_ai_status():
    """Get status of both AI providers."""
    settings = get_runtime_settings()
    ollama_url = settings.get('ollama_url') or Config.OLLAMA_BASE_URL
    ollama_model = settings.get('ollama_model') or Config.OLLAMA_MODEL
    openrouter_api_key = settings.get('openrouter_api_key') or Config.OPENROUTER_API_KEY
    openrouter_model = settings.get('openrouter_model') or Config.OPENROUTER_MODEL
    
    ollama_available = check_ollama_available()
    openrouter_available = check_openrouter_available()
    
    # Determine default provider
    default_provider = 'openrouter' if openrouter_api_key else 'ollama'
    
    return {
        'ollama': {
            'available': ollama_available,
            'url': ollama_url,
            'model': ollama_model
        },
        'openrouter': {
            'available': openrouter_available,
            'configured': bool(openrouter_api_key),
            'model': openrouter_model
        },
        'default_provider': default_provider
    }