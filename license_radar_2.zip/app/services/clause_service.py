CLAUSE_TAXONOMY = {
    'copyleft': {
        'label': 'Copyleft',
        'description': 'Requirements to share source code of derivative works',
        'risk_level': 'critical',
        'icon': 'copyright'
    },
    'network_use': {
        'label': 'Network Use',
        'description': 'Network interaction triggers distribution obligations',
        'risk_level': 'critical',
        'icon': 'globe'
    },
    'patent': {
        'label': 'Patent',
        'description': 'Patent grant and termination clauses',
        'risk_level': 'warning',
        'icon': '专利'
    },
    'commercial_restriction': {
        'label': 'Commercial Restriction',
        'description': 'Restrictions on commercial use',
        'risk_level': 'critical',
        'icon': 'attach_money'
    },
    'trademark': {
        'label': 'Trademark',
        'description': 'Restrictions on using vendor trademarks',
        'risk_level': 'warning',
        'icon': 'verified_user'
    },
    'attribution': {
        'label': 'Attribution',
        'description': 'Requirements to credit the original authors',
        'risk_level': 'info',
        'icon': 'badge'
    },
    'warranty_liability': {
        'label': 'Warranty & Liability',
        'description': 'Disclaimer of warranties and limitation of liability',
        'risk_level': 'info',
        'icon': 'gavel'
    },
    'export_control': {
        'label': 'Export Control',
        'description': 'Export control and encryption restrictions',
        'risk_level': 'warning',
        'icon': 'lock'
    },
    'data_processing': {
        'label': 'Data Processing',
        'description': 'Data processing and privacy provisions',
        'risk_level': 'warning',
        'icon': 'storage'
    }
}

RISK_MAPPING = {
    'AGPL': 'critical',
    'GPL': 'critical',
    'LGPL': 'warning',
    'MIT': 'info',
    'BSD': 'info',
    'Apache': 'info',
    'Commercial': 'warning',
    'Proprietary': 'warning'
}

DEPLOYMENT_SCOPES = ['internal', 'external', 'both']

def get_clause_type_label(clause_type):
    return CLAUSE_TAXONOMY.get(clause_type, {}).get('label', clause_type.replace('_', ' ').title())

def get_risk_level_color(risk_level):
    colors = {
        'critical': '#ef4444',
        'warning': '#f59e0b',
        'info': '#22c55e'
    }
    return colors.get(risk_level, '#6b7280')

def get_risk_level_label(risk_level):
    labels = {
        'critical': 'Critical',
        'warning': 'Warning',
        'info': 'Info'
    }
    return labels.get(risk_level, risk_level.title())

def get_risk_level_pill_class(risk_level):
    classes = {
        'critical': 'pill--critical',
        'warning': 'pill--warning',
        'info': 'pill--info'
    }
    return classes.get(risk_level, 'pill--pending')

def estimate_risk_from_license_name(license_name):
    if not license_name:
        return 'info'
    
    license_upper = license_name.upper()
    
    for key, risk in RISK_MAPPING.items():
        if key in license_upper:
            return risk
    
    return 'info'

def validate_clause_type(clause_type):
    return clause_type in CLAUSE_TAXONOMY

def validate_risk_level(risk_level):
    return risk_level in ['critical', 'warning', 'info']

def validate_deployment_scope(scope):
    return scope in DEPLOYMENT_SCOPES