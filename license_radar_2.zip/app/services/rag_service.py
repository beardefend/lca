import os
import json
import logging
import requests
from config import Config

logger = logging.getLogger(__name__)

RAG_DATA_FILE = os.path.join(Config.CHROMA_PERSIST_DIR or './data', 'rag_index.json')

DEFAULT_SYSTEM_PROMPT = """You are a license compliance analyst for a bank. Using only the license information provided, answer the question. If the answer is not in the provided context, say so."""

def get_runtime_settings():
    """Get settings from database at runtime.
    
    Priority order:
    1. Database settings (Admin Panel) - HIGHEST PRIORITY
    2. Environment variables - as fallback
    """
    import os
    settings = {}
    
    # First try environment variables
    env_key = os.environ.get('OPENROUTER_API_KEY')
    if env_key:
        settings['openrouter_api_key'] = env_key
    
    env_model = os.environ.get('OPENROUTER_MODEL')
    if env_model:
        settings['openrouter_model'] = env_model
    
    env_ollama = os.environ.get('OLLAMA_BASE_URL')
    if env_ollama:
        settings['ollama_url'] = env_ollama
        
    env_ollama_model = os.environ.get('OLLAMA_MODEL')
    if env_ollama_model:
        settings['ollama_model'] = env_ollama_model
    
    # Database settings override environment variables
    try:
        from app.models import Settings
        from app import Session
        session = Session()
        
        db_settings = session.query(Settings).all()
        for s in db_settings:
            if s.value:
                settings[s.key] = s.value
        
        session.close()
    except Exception as e:
        logger.warning(f"Could not load settings from database: {e}")
    
    return settings

def _ensure_dir():
    os.makedirs(Config.CHROMA_PERSIST_DIR or './data', exist_ok=True)

def _load_index():
    _ensure_dir()
    if os.path.exists(RAG_DATA_FILE):
        try:
            with open(RAG_DATA_FILE, 'r') as f:
                return json.load(f)
        except:
            return {'documents': [], 'metadatas': []}
    return {'documents': [], 'metadatas': []}

def _save_index(data):
    _ensure_dir()
    with open(RAG_DATA_FILE, 'w') as f:
        json.dump(data, f)

def embed_license(license_id):
    """Store license text for RAG - simplified for v1."""
    from app.models import License
    from app import Session
    
    session = Session()
    license = session.query(License).get(license_id)
    
    if not license or not license.license_text:
        session.close()
        return False
    
    component = license.component
    app = component.application if component else None
    team = app.team if app else None
    
    try:
        data = _load_index()
        
        data['documents'].append(license.license_text)
        data['metadatas'].append({
            'license_id': license.id,
            'license_name': license.license_name,
            'spdx_id': license.spdx_id or '',
            'component_name': component.name if component else '',
            'application_name': app.name if app else '',
            'team_name': team.name if team else '',
            'environment': app.environment if app else ''
        })
        
        _save_index(data)
        session.close()
        return True
    
    except Exception as e:
        session.close()
        logger.error(f"Failed to store license for RAG: {e}")
        return False

def search_license(query_text, license_id=None, top_k=5):
    """Search for relevant license text(s)."""
    try:
        data = _load_index()
        
        if not data.get('documents'):
            return {'documents': [], 'sources': []}
        
        query_lower = query_text.lower()
        results = []
        
        for i, doc in enumerate(data.get('documents', [])):
            doc_lower = doc.lower()
            meta = data.get('metadatas', [])[i] if i < len(data.get('metadatas', [])) else {}
            
            if license_id is not None:
                meta_id = meta.get('license_id')
                if meta_id != license_id:
                    continue
            
            score = sum([
                1 if query_lower in doc_lower else 0,
                1 if any(w in doc_lower for w in query_lower.split()[:3]) else 0,
                2 if meta.get('license_name', '').lower() in query_lower else 0
            ])
            
            if score > 0 or license_id is not None:
                results.append({
                    'index': i,
                    'score': score / max(len(doc_lower), 1),
                    'document': doc[:2000],
                    'metadata': meta
                })
        
        if license_id is not None:
            for r in results:
                if r['metadata'].get('license_id') == license_id:
                    results = [r]
                    break
            else:
                results = results[:1] if results else []
        
        results.sort(key=lambda x: x['score'], reverse=True)
        results = results[:top_k]
        
        sources = []
        for r in results:
            m = r['metadata']
            sources.append({
                'license_id': m.get('license_id'),
                'license_name': m.get('license_name'),
                'spdx_id': m.get('spdx_id'),
                'component_name': m.get('component_name'),
                'application_name': m.get('application_name'),
                'team_name': m.get('team_name'),
                'relevance': r['score']
            })
        
        documents = [r['document'] for r in results]
        
        return {
            'documents': documents,
            'sources': sources
        }
    
    except Exception as e:
        logger.error(f"Search error: {e}")
        return {'documents': [], 'sources': [], 'error': str(e)}

def _check_ollama_available(url):
    try:
        response = requests.get(f"{url}/api/tags", timeout=10)
        if response.status_code == 200:
            data = response.json()
            return [m['name'] for m in data.get('models', [])]
        return []
    except Exception:
        return []

def _check_openrouter_available():
    """Check if OpenRouter API is configured."""
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key') or Config.OPENROUTER_API_KEY
    if not api_key:
        return False
    try:
        response = requests.get(
            f"{Config.OPENROUTER_BASE_URL}/models",
            headers={'Authorization': f'Bearer {api_key}'},
            timeout=5
        )
        return response.status_code == 200
    except Exception:
        return False

def _answer_with_openrouter(prompt, model=None, temperature=0.1, max_tokens=1000):
    """Answer using OpenRouter API."""
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key')
    
    if not api_key:
        return None, 'OpenRouter API key not configured. Please go to Admin > Settings and enter your API key.'
    
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:5000',
            'X-Title': 'License Radar'
        }
        
        if model is None:
            model = settings.get('openrouter_model', 'anthropic/claude-3-haiku')
        
        payload = {
            'model': model,
            'messages': [
                {'role': 'system', 'content': DEFAULT_SYSTEM_PROMPT},
                {'role': 'user', 'content': prompt}
            ],
            'temperature': temperature,
            'max_tokens': max_tokens
        }
        
        response = requests.post(
            f"{Config.OPENROUTER_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
            timeout=Config.OLLAMA_TIMEOUT_SECONDS
        )
        
        if response.status_code != 200:
            return None, f'OpenRouter error: {response.status_code} - {response.text[:200]}'
        
        result = response.json()
        answer = result['choices'][0]['message']['content']
        return answer.strip(), None
        
    except Exception as e:
        return None, str(e)

def answer_with_rag(query, license_id=None, model=None, temperature=None, max_tokens=None, system_prompt=None, ollama_url=None, provider=None):
    """Answer a question using simple search + OpenRouter/Ollama."""
    # Get runtime settings from database (single source of truth)
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key')
    
    # Determine provider: default to OpenRouter if API key is set, else Ollama
    if provider is None:
        provider = 'openrouter' if api_key else 'ollama'
    
    if temperature is None:
        temperature = 0.1
    if max_tokens is None:
        max_tokens = 1000
    if system_prompt is None:
        system_prompt = DEFAULT_SYSTEM_PROMPT
    
    # Search for relevant documents
    search_results = search_license(query, license_id=license_id, top_k=3)
    
    if not search_results.get('documents'):
        return {
            'answer': 'No relevant license information found. Please upload and analyze licenses first.',
            'sources': [],
            'provider': provider
        }
    
    context = "\n\n".join(search_results['documents'])
    
    prompt = f"""{system_prompt}

Context:
{context}

Question: {query}"""
    
    # Use OpenRouter
    if provider == 'openrouter':
        settings = get_runtime_settings()
        if not settings.get('openrouter_api_key'):
            return {
                'answer': 'OpenRouter API key is not configured. Please go to Admin > Settings and enter your API key.',
                'sources': [],
                'provider': 'openrouter'
            }
        
        # ALWAYS use model from database settings for OpenRouter
        # Ignore the model parameter from request - use Admin Settings
        openrouter_model = settings.get('openrouter_model', 'anthropic/claude-3-haiku')
        answer, error = _answer_with_openrouter(prompt, openrouter_model, temperature, max_tokens)
        
        if error:
            return {
                'answer': f'OpenRouter error: {error}',
                'sources': search_results.get('sources', []),
                'provider': 'openrouter'
            }
        
        return {
            'answer': answer,
            'sources': search_results.get('sources', []),
            'provider': 'openrouter'
        }
    
    # Use Ollama (fallback)
    if ollama_url is None:
        ollama_url = Config.OLLAMA_BASE_URL
    if model is None:
        model = Config.OLLAMA_MODEL
    
    # Check Ollama availability
    if not _check_ollama_available(ollama_url):
        return {
            'answer': f'Ollama is not available at {ollama_url}. Please check:\n1. Ollama is running\n2. URL is correct in Settings\n3. No firewall blocking the connection',
            'sources': [],
            'provider': 'ollama'
        }
    
    try:
        payload = {
            'model': model,
            'prompt': prompt,
            'stream': False,
            'options': {
                'temperature': temperature,
                'num_predict': max_tokens
            }
        }
        
        response = requests.post(
            f"{ollama_url}/api/generate",
            json=payload,
            timeout=Config.OLLAMA_TIMEOUT_SECONDS
        )
        
        content_type = response.headers.get('content-type', '')
        if 'html' in content_type.lower():
            return {
                'answer': f'Ollama returned HTML at {ollama_url}. The URL may be incorrect.',
                'sources': search_results.get('sources', []),
                'provider': 'ollama'
            }
        
        if response.status_code != 200:
            return {
                'answer': f'Ollama API error: HTTP {response.status_code}',
                'sources': search_results.get('sources', []),
                'provider': 'ollama'
            }
        
        result = response.json()
        answer = result.get('response', '')
        
        return {
            'answer': answer.strip(),
            'sources': search_results.get('sources', []),
            'provider': 'ollama'
        }
    
    except requests.exceptions.ConnectionError:
        logger.error(f"Ollama connection error to {ollama_url}")
        return {
            'answer': f'Cannot connect to Ollama at {ollama_url}. Check if URL is correct and Ollama is running.',
            'sources': search_results.get('sources', []),
            'provider': 'ollama'
        }
    except Exception as e:
        logger.error(f"RAG answer error: {e}")
        return {
            'answer': f'Error: {str(e)}',
            'sources': search_results.get('sources', []),
            'provider': provider
        }