import json
import requests
from app.models import License, Settings
from app import Session
from config import Config
import logging

logger = logging.getLogger(__name__)

def get_runtime_settings():
    """Get settings from database at runtime.
    
    Priority order:
    1. Database settings (Admin Panel) - HIGHEST PRIORITY
    2. Environment variables - as fallback
    """
    import os
    settings = {}
    
    # First try environment variables
    env_key = os.environ.get('OPENROUTER_API_KEY')
    if env_key:
        settings['openrouter_api_key'] = env_key
    
    env_model = os.environ.get('OPENROUTER_MODEL')
    if env_model:
        settings['openrouter_model'] = env_model
    
    env_ollama = os.environ.get('OLLAMA_BASE_URL')
    if env_ollama:
        settings['ollama_url'] = env_ollama
        
    env_ollama_model = os.environ.get('OLLAMA_MODEL')
    if env_ollama_model:
        settings['ollama_model'] = env_ollama_model
    
    # Database settings override environment variables
    try:
        session = Session()
        
        db_settings = session.query(Settings).all()
        for s in db_settings:
            if s.value:
                settings[s.key] = s.value
        
        session.close()
    except Exception as e:
        logger.warning(f"Could not load settings from database: {e}")
    
    return settings

SYSTEM_PROMPT = """You are a software license compliance analyst. Analyze the license text and provide assessment for all 25 points below.

For each point, select ONE option from the provided choices and provide a brief note explaining your answer based on the license text.

## Points to Assess:

### Usage Rights (3 points)
1. Internal Use Allowed: Yes, No, Conditional, Unknown, Needs Legal Review
2. External Use Allowed: Yes, No, Conditional, Unknown, Needs Legal Review  
3. Enterprise Use Allowed: Yes, No, Paid Required, Conditional, Unknown, Needs Legal Review

### Modification & Security (5 points)
4. Source Code Access: Full, Partial, None, Unknown
5. Modification Allowed: Yes, No, Conditional, Unknown, Needs Legal Review
6. Security Fix Allowed: Yes, No, Vendor Only, Conditional, Unknown
7. Copyleft Requirement: None, Weak, Strong, Network Copyleft, Unknown, Needs Legal Review
8. Source Disclosure Required: Yes, No, Conditional, Unknown, Needs Legal Review

### Deployment & Distribution (3 points)
9. Redistribution Allowed: Yes, No, Conditional, Unknown
10. SaaS / Cloud Use Allowed: Yes, No, Conditional, Grey Area, Unknown, Needs Legal Review
11. On-Prem Deployment Allowed: Yes, No, Conditional, Unknown

### Commercial & Legal (5 points)
12. License Cost: Free, Paid, Freemium, Tiered, Unknown
13. Enterprise License Required: Yes, No, Conditional, Unknown, Needs Legal Review
14. Legal Risk Level: Low, Medium, High, Critical, Needs Legal Review
15. Compliance Complexity: Low, Medium, High, Unknown
16. Audit Risk: Low, Medium, High, Unknown, Needs Legal Review

### Support & Control (2 points)
17. Support Type: Community, Paid Support, Vendor Support, None, Unknown
18. Update Control: Full Control, Vendor Controlled, Mixed, Forced Updates, Unknown

### Final Decision (3 points)
19. Overall Risk Rating: Low, Medium, High, Critical
20. Approval Status: Approved, Rejected, Conditional, Pending Review, Needs Legal Review
21. Usage Scope: Internal Only, External Allowed, Enterprise Allowed, Restricted, Not Allowed, Needs Legal Review

## Output Format (JSON ONLY):
Return valid JSON with all 25 assessments:
{
  "internal_use": "value",
  "internal_use_note": "reasoning",
  "external_use": "value", 
  "external_use_note": "reasoning",
  ... repeat for all 25 points ...
}

License Text:
{license_text}

Analyze and return JSON:"""

def check_ollama_available():
    try:
        response = requests.get(f"{Config.OLLAMA_BASE_URL}/api/tags", timeout=5)
        return response.status_code == 200
    except:
        return False

def check_openrouter_available():
    """Check if OpenRouter API is configured."""
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key')
    if not api_key:
        return False
    try:
        response = requests.get(
            f"{Config.OPENROUTER_BASE_URL}/models",
            headers={'Authorization': f'Bearer {api_key}'},
            timeout=5
        )
        return response.status_code == 200
    except:
        return False

def run_ai_assessment_with_openrouter(license_text):
    """Run AI assessment using OpenRouter."""
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key')
    
    if not api_key:
        return None, 'OpenRouter API key not configured. Please go to Admin > Settings and enter your API key.'
    
    model = settings.get('openrouter_model') or Config.OPENROUTER_MODEL
    
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:5000',
            'X-Title': 'License Radar'
        }
        
        prompt = SYSTEM_PROMPT.replace('{license_text}', license_text[:6000])
        
        payload = {
            'model': model,
            'messages': [
                {'role': 'system', 'content': 'You are a software license compliance analyst.'},
                {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.1,
            'max_tokens': 2000
        }
        
        response = requests.post(
            f"{Config.OPENROUTER_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
            timeout=Config.OLLAMA_TIMEOUT_SECONDS
        )
        
        if response.status_code != 200:
            return None, f'OpenRouter error: {response.status_code}'
        
        result = response.json()
        response_text = result['choices'][0]['message']['content']
        
        start = response_text.find('{')
        end = response_text.rfind('}') + 1
        if start == -1 or end == 0:
            return None, 'Could not parse AI response'
        
        json_str = response_text[start:end]
        data = json.loads(json_str)
        return data, None
        
    except Exception as e:
        return None, str(e)

def run_ai_assessment(license_id, provider=None):
    session = Session()
    license = session.query(License).get(license_id)
    
    if not license:
        session.close()
        return {'success': False, 'error': 'License not found'}
    
    # Determine provider
    if provider is None:
        provider = 'openrouter' if Config.OPENROUTER_API_KEY else 'ollama'
    
    data = None
    error = None
    
    if provider == 'openrouter':
        data, error = run_ai_assessment_with_openrouter(license.license_text[:6000])
    else:
        # Ollama
        if not check_ollama_available():
            session.close()
            return {'success': False, 'error': 'Ollama not available', 'provider': 'ollama'}
        data, error = run_ai_assessment_with_ollama(license.license_text[:6000])
    
    if error:
        license.analysis_status = 'failed'
        session.commit()
        session.close()
        return {'success': False, 'error': error, 'provider': provider}
    
    # Update license with assessment data
    for key, value in data.items():
        if hasattr(license, key):
            setattr(license, key, value)
    
    license.analyzed_at = __import__('datetime').datetime.utcnow()
    license.analysis_status = 'done'
    
    session.commit()
    session.close()
    
    return {'success': True, 'assessments': data, 'provider': provider}

# Assessment Questions and Options for 25-Point Assessment
ASSESSMENT_QUESTIONS = [
    ('Usage Rights', [
        ('internal_use', 'Internal Use Allowed', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('external_use', 'External Use Allowed', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('enterprise_use', 'Enterprise Use Allowed', 'Yes,No,Paid Required,Conditional,Unknown,Needs Legal Review'),
    ]),
    ('Modification & Security', [
        ('source_code_access', 'Source Code Access', 'Full,Partial,None,Unknown'),
        ('modification_allowed', 'Modification Allowed', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('security_fix_allowed', 'Security Fix Allowed', 'Yes,No,Vendor Only,Conditional,Unknown'),
        ('copyleft_requirement', 'Copyleft Requirement', 'None,Weak,Strong,Network Copyleft,Unknown,Needs Legal Review'),
        ('source_disclosure', 'Source Disclosure Required', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
    ]),
    ('Deployment & Distribution', [
        ('redistribution_allowed', 'Redistribution Allowed', 'Yes,No,Conditional,Unknown'),
        ('saas_cloud_use', 'SaaS / Cloud Use Allowed', 'Yes,No,Conditional,Grey Area,Unknown,Needs Legal Review'),
        ('onpremise_deployment', 'On-Prem Deployment Allowed', 'Yes,No,Conditional,Unknown'),
    ]),
    ('Commercial & Legal', [
        ('license_cost', 'License Cost', 'Free,Paid,Freemium,Tiered,Unknown'),
        ('enterprise_license', 'Enterprise License Required', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('legal_risk_level', 'Legal Risk Level', 'Low,Medium,High,Critical,Needs Legal Review'),
        ('compliance_complexity', 'Compliance Complexity', 'Low,Medium,High,Unknown'),
        ('audit_risk', 'Audit Risk', 'Low,Medium,High,Unknown,Needs Legal Review'),
    ]),
    ('Support & Control', [
        ('support_type', 'Support Type', 'Community,Paid Support,Vendor Support,None,Unknown'),
        ('update_control', 'Update Control', 'Full Control,Vendor Controlled,Mixed,Forced Updates,Unknown'),
    ]),
    ('Final Decision', [
        ('overall_risk_rating', 'Overall Risk Rating', 'Low,Medium,High,Critical'),
        ('approval_status', 'Approval Status', 'Approved,Rejected,Conditional,Pending Review,Needs Legal Review'),
        ('usage_scope', 'Usage Scope', 'Internal Only,External Allowed,Enterprise Allowed,Restricted,Not Allowed,Needs Legal Review'),
    ]),
]

def build_assessment_prompt(license_text):
    prompt = """You are a software license compliance analyst. Analyze the license text and answer all 25 assessment questions.

For each question:
- Select ONE option from the provided choices
- Provide a brief note explaining your reasoning in plain text

## Questions:

"""
    question_num = 1
    for section_name, fields in ASSESSMENT_QUESTIONS:
        prompt += f"### {section_name}\n"
        for field_key, field_label, options in fields:
            prompt += f"{question_num}. {field_label} - Options: {options}\n"
            question_num += 1
    
    prompt += """
## Output Format (JSON ONLY):
Return valid JSON with all 25 fields and their notes. Use underscore_format for field names.
Example: {"internal_use": "Yes", "internal_use_note": "Plain text reasoning..."}

License Text:
"""
    prompt += license_text[:8000] + "\n\nAnalyze and return JSON:"
    return prompt

def run_ai_assessment_25_points(license_text):
    logger.info("Starting 25-point AI assessment")
    
    settings = get_runtime_settings()
    api_key = settings.get('openrouter_api_key')
    
    logger.info(f"API key loaded: {'Yes' if api_key else 'No'}")
    
    if not api_key:
        logger.error("OpenRouter API key not configured")
        return {'success': False, 'error': 'OpenRouter API key not configured. Please go to Admin > Settings.'}
    
    model = settings.get('openrouter_model', 'anthropic/claude-3-haiku')
    logger.info(f"Using model: {model}")
    
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:5000',
            'X-Title': 'License Radar'
        }
        
        prompt = build_assessment_prompt(license_text)
        logger.info(f"Prompt built, length: {len(prompt)} chars")
        
        payload = {
            'model': model,
            'messages': [
                {'role': 'system', 'content': 'You are a software license compliance analyst. Always return valid JSON.'},
                {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.1,
            'max_tokens': 4000
        }
        
        response = requests.post(
            f"{Config.OPENROUTER_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
            timeout=Config.OLLAMA_TIMEOUT_SECONDS
        )
        
        if response.status_code != 200:
            return {'success': False, 'error': f'OpenRouter error: {response.status_code} - {response.text[:200]}'}
        
        result = response.json()
        response_text = result['choices'][0]['message']['content']
        
        start = response_text.find('{')
        end = response_text.rfind('}') + 1
        if start == -1 or end == 0:
            return {'success': False, 'error': 'Could not parse AI response as JSON'}
        
        json_str = response_text[start:end]
        data = json.loads(json_str)
        
        cleaned_data = {}
        for key, value in data.items():
            if key.endswith('_note'):
                value = value.replace('**', '').replace('*', '').replace('#', '').replace('`', '')
                cleaned_data[key] = value.strip()
            else:
                cleaned_data[key] = value
        
        logger.info("Assessment completed successfully")
        return {'success': True, 'assessments': cleaned_data}
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse error: {e}")
        return {'success': False, 'error': f'Failed to parse AI response: {str(e)}'}
    except Exception as e:
        logger.error(f"Assessment error: {e}")
        return {'success': False, 'error': str(e)}

def run_ai_assessment_with_ollama(license_text):
    """Run AI assessment using Ollama."""
    try:
        prompt = SYSTEM_PROMPT.replace('{license_text}', license_text[:6000])
        
        payload = {
            'model': Config.OLLAMA_MODEL,
            'prompt': prompt,
            'stream': False,
            'options': {'temperature': 0.1, 'num_predict': 2000}
        }
        
        response = requests.post(
            f"{Config.OLLAMA_BASE_URL}/api/generate",
            json=payload,
            timeout=Config.OLLAMA_TIMEOUT_SECONDS
        )
        
        if response.status_code != 200:
            return None, f'Ollama error: {response.status_code}'
        
        result = response.json()
        response_text = result.get('response', '')
        
        start = response_text.find('{')
        end = response_text.rfind('}') + 1
        if start == -1 or end == 0:
            return None, 'Could not parse AI response'
        
        json_str = response_text[start:end]
        data = json.loads(json_str)
        return data, None
        
    except Exception as e:
        return None, str(e)