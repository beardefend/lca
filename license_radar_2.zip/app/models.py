from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app import engine
from sqlalchemy.ext.declarative import declarative_base
from flask_login import UserMixin

Base = declarative_base()

class User(Base, UserMixin):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(120), nullable=False)
    role = Column(Enum('admin', 'analyst', 'viewer'), nullable=False, default='viewer')
    team_id = Column(Integer, ForeignKey('teams.id'), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    last_login = Column(DateTime, nullable=True)
    
    team = relationship('Team', back_populates='users')
    
    @property
    def is_authenticated(self):
        return self.is_active
    
    @property
    def is_anonymous(self):
        return False
    
    def get_id(self):
        return str(self.id)

class Team(Base):
    __tablename__ = 'teams'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    users = relationship('User', back_populates='team')
    applications = relationship('Application', back_populates='team')

class Application(Base):
    __tablename__ = 'applications'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    team_id = Column(Integer, ForeignKey('teams.id'), nullable=False)
    environment = Column(Enum('internal', 'external', 'both'), nullable=False, default='internal')
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    created_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    
    team = relationship('Team', back_populates='applications')
    components = relationship('Component', back_populates='application', cascade='all, delete-orphan')
    creator = relationship('User')

class Component(Base):
    __tablename__ = 'components'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('applications.id'), nullable=False)
    name = Column(String(150), nullable=False)
    version = Column(String(50), nullable=True)
    vendor = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    application = relationship('Application', back_populates='components')
    licenses = relationship('License', back_populates='component', cascade='all, delete-orphan')

class License(Base):
    __tablename__ = 'licenses'
    
    id = Column(Integer, primary_key=True)
    component_id = Column(Integer, ForeignKey('components.id'), nullable=False)
    spdx_id = Column(String(50), nullable=True)
    license_name = Column(String(150), nullable=False)
    license_text = Column(Text, nullable=False)
    file_path = Column(String(255), nullable=True)
    analysis_status = Column(Enum('pending', 'done', 'failed'), nullable=False, default='pending')
    analyzed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    # 25 Assessment fields
    internal_use = Column(String(30), nullable=True)
    internal_use_note = Column(Text, nullable=True)
    external_use = Column(String(30), nullable=True)
    external_use_note = Column(Text, nullable=True)
    enterprise_use = Column(String(30), nullable=True)
    enterprise_use_note = Column(Text, nullable=True)
    source_code_access = Column(String(30), nullable=True)
    source_code_access_note = Column(Text, nullable=True)
    modification_allowed = Column(String(30), nullable=True)
    modification_allowed_note = Column(Text, nullable=True)
    security_fix_allowed = Column(String(30), nullable=True)
    security_fix_allowed_note = Column(Text, nullable=True)
    copyleft_requirement = Column(String(30), nullable=True)
    copyleft_requirement_note = Column(Text, nullable=True)
    source_disclosure = Column(String(30), nullable=True)
    source_disclosure_note = Column(Text, nullable=True)
    redistribution_allowed = Column(String(30), nullable=True)
    redistribution_allowed_note = Column(Text, nullable=True)
    saas_cloud_use = Column(String(30), nullable=True)
    saas_cloud_use_note = Column(Text, nullable=True)
    onpremise_deployment = Column(String(30), nullable=True)
    onpremise_deployment_note = Column(Text, nullable=True)
    license_cost = Column(String(30), nullable=True)
    license_cost_note = Column(Text, nullable=True)
    enterprise_license = Column(String(30), nullable=True)
    enterprise_license_note = Column(Text, nullable=True)
    legal_risk_level = Column(String(30), nullable=True)
    legal_risk_level_note = Column(Text, nullable=True)
    compliance_complexity = Column(String(30), nullable=True)
    compliance_complexity_note = Column(Text, nullable=True)
    audit_risk = Column(String(30), nullable=True)
    audit_risk_note = Column(Text, nullable=True)
    support_type = Column(String(30), nullable=True)
    support_type_note = Column(Text, nullable=True)
    update_control = Column(String(30), nullable=True)
    update_control_note = Column(Text, nullable=True)
    overall_risk_rating = Column(String(30), nullable=True)
    overall_risk_rating_note = Column(Text, nullable=True)
    approval_status = Column(String(30), nullable=True)
    approval_status_note = Column(Text, nullable=True)
    usage_scope = Column(String(30), nullable=True)
    usage_scope_note = Column(Text, nullable=True)
    
    component = relationship('Component', back_populates='licenses')
    clauses = relationship('Clause', back_populates='license', cascade='all, delete-orphan')

class Clause(Base):
    __tablename__ = 'clauses'
    
    id = Column(Integer, primary_key=True)
    license_id = Column(Integer, ForeignKey('licenses.id'), nullable=False)
    clause_type = Column(Enum('copyleft', 'network_use', 'patent', 'commercial_restriction', 'trademark', 'attribution', 'warranty_liability', 'export_control', 'data_processing'), nullable=False)
    clause_title = Column(String(200), nullable=False)
    clause_text = Column(Text, nullable=False)
    risk_level = Column(Enum('critical', 'warning', 'info'), nullable=False)
    deployment_scope = Column(Enum('internal', 'external', 'both'), nullable=False, default='both')
    ai_explanation = Column(Text, nullable=True)
    analysis_source = Column(Enum('manual', 'ai'), nullable=False, default='manual')
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    license = relationship('License', back_populates='clauses')

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    action = Column(String(50), nullable=False)
    target_type = Column(String(50), nullable=True)
    target_id = Column(Integer, nullable=True)
    detail = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=func.now())
    ip_address = Column(String(45), nullable=True)
    
    user = relationship('User')

CLAUSE_TYPES = [
    'copyleft',
    'network_use', 
    'patent',
    'commercial_restriction',
    'trademark',
    'attribution',
    'warranty_liability',
    'export_control',
    'data_processing'
]

RISK_LEVELS = ['critical', 'warning', 'info']

def init_db():
    Base.metadata.create_all(engine)

def get_session():
    from app import Session
    return Session

class Settings(Base):
    __tablename__ = 'settings'
    
    id = Column(Integer, primary_key=True)
    key = Column(String(100), unique=True, nullable=False)
    value = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())