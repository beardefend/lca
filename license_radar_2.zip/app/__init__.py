import os
from flask import Flask
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from config import Config

db_path = Config.DATABASE_PATH
os.makedirs(os.path.dirname(db_path) if os.path.dirname(db_path) else '.', exist_ok=True)
db_uri = f'sqlite:///{db_path}'

engine = create_engine(db_uri, echo=Config.DEBUG)
Session = scoped_session(sessionmaker(bind=engine))

login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

csrf = CSRFProtect()
limiter = Limiter(key_func=lambda: '127.0.0.1')

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    from app.models import User
    
    @login_manager.user_loader
    def load_user(user_id):
        return Session.query(User).get(int(user_id))

    from app.routes import auth, dashboard, applications, licenses, admin, api, compliance, assessment
    app.register_blueprint(auth.bp)
    app.register_blueprint(dashboard.bp)
    app.register_blueprint(applications.bp)
    app.register_blueprint(licenses.bp)
    app.register_blueprint(admin.bp)
    app.register_blueprint(api.bp)
    app.register_blueprint(compliance.bp)
    app.register_blueprint(assessment.bp)

    @app.teardown_appcontext
    def shutdown_session(exception=None):
        Session.remove()

    return app