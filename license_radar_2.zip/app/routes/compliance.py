from flask import Blueprint, render_template, request, make_response
from flask_login import login_required, current_user
from app.models import Application, Component, License, Team
from app import Session
from sqlalchemy import func
import openpyxl
import io
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime

bp = Blueprint('compliance', __name__, url_prefix='/compliance')

ASSESSMENT_POINTS = [
    ('Usage Rights', [
        ('internal_use', 'Internal'),
        ('external_use', 'External'),
        ('enterprise_use', 'Enterprise'),
    ]),
    ('Modification & Security', [
        ('source_code_access', 'Source'),
        ('modification_allowed', 'Modify'),
        ('security_fix_allowed', 'Security'),
        ('copyleft_requirement', 'Copyleft'),
        ('source_disclosure', 'Disclosure'),
    ]),
    ('Deployment', [
        ('redistribution_allowed', 'Redistribute'),
        ('saas_cloud_use', 'SaaS/Cloud'),
        ('onpremise_deployment', 'On-Prem'),
    ]),
    ('Commercial', [
        ('license_cost', 'Cost'),
        ('enterprise_license', 'Enterprise'),
        ('legal_risk_level', 'Legal Risk'),
        ('compliance_complexity', 'Compliance'),
        ('audit_risk', 'Audit'),
    ]),
    ('Support', [
        ('support_type', 'Support'),
        ('update_control', 'Updates'),
    ]),
    ('Final Decision', [
        ('overall_risk_rating', 'Risk'),
        ('approval_status', 'Approved'),
        ('usage_scope', 'Scope'),
    ]),
]

NOTE_FIELDS = [
    'internal_use_note', 'external_use_note', 'enterprise_use_note',
    'source_code_access_note', 'modification_allowed_note', 'security_fix_allowed_note',
    'copyleft_requirement_note', 'source_disclosure_note',
    'redistribution_allowed_note', 'saas_cloud_use_note', 'onpremise_deployment_note',
    'license_cost_note', 'enterprise_license_note', 'legal_risk_level_note',
    'compliance_complexity_note', 'audit_risk_note',
    'support_type_note', 'update_control_note',
    'overall_risk_rating_note', 'approval_status_note', 'usage_scope_note',
]

FIELD_LABELS = {
    'internal_use_note': 'Internal',
    'external_use_note': 'External',
    'enterprise_use_note': 'Enterprise',
    'source_code_access_note': 'Source',
    'modification_allowed_note': 'Modify',
    'security_fix_allowed_note': 'Security',
    'copyleft_requirement_note': 'Copyleft',
    'source_disclosure_note': 'Disclosure',
    'redistribution_allowed_note': 'Redistribute',
    'saas_cloud_use_note': 'SaaS/Cloud',
    'onpremise_deployment_note': 'On-Prem',
    'license_cost_note': 'Cost',
    'enterprise_license_note': 'Enterprise',
    'legal_risk_level_note': 'Legal Risk',
    'compliance_complexity_note': 'Compliance',
    'audit_risk_note': 'Audit',
    'support_type_note': 'Support',
    'update_control_note': 'Updates',
    'overall_risk_rating_note': 'Risk',
    'approval_status_note': 'Approved',
    'usage_scope_note': 'Scope',
}

@bp.route('')
@login_required
def index():
    session = Session()
    
    team_filter = request.args.get('team')
    env_filter = request.args.get('environment')
    status_filter = request.args.get('status')
    
    # Query over Component (one row per component)
    query = session.query(Component).join(Application, Component.application_id == Application.id)
    if current_user.role == 'viewer' and current_user.team_id:
        query = query.filter(Application.team_id == current_user.team_id)
    
    if team_filter:
        query = query.filter(Application.team_id == int(team_filter))
    if env_filter:
        query = query.filter(Application.environment == env_filter)
    
    components = query.order_by(Application.name, Component.name).all()
    teams = session.query(Team).all()
    
    # Build matrix data - one row per component
    matrix_data = []
    for comp in components:
        app = comp.application
        row = {'app': app, 'component': comp, 'team': app.team, 'cells': {}, 'status': 'not_started', 'license_name': '', 'spdx_id': ''}
        
        # Get license with assessment data for this component
        for lic in comp.licenses:
            if lic.overall_risk_rating:
                row['status'] = lic.approval_status or 'pending'
                row['license_name'] = lic.license_name or ''
                row['spdx_id'] = lic.spdx_id or ''
                for section_name, fields in ASSESSMENT_POINTS:
                    for field_key, label in fields:
                        value = getattr(lic, field_key, None)
                        row['cells'][field_key] = value
                break  # Use first license with assessment data
        
        # Apply status filter (if specified)
        if status_filter:
            if status_filter == 'not_assessed':
                if row['status'] != 'not_started':
                    continue  # Skip - has assessment
            elif row['status'] != status_filter:
                continue  # Skip - doesn't match filter
        
        matrix_data.append(row)
    
    return render_template('compliance/index.html',
                   matrix_data=matrix_data,
                   teams=teams,
                   assessment_points=ASSESSMENT_POINTS,
                   team_filter=team_filter,
                   env_filter=env_filter,
                   status_filter=status_filter)

@bp.route('/export')
@login_required
def export():
    session = Session()
    
    team_filter = request.args.get('team')
    env_filter = request.args.get('environment')
    status_filter = request.args.get('status')
    
    # Build same query as index
    query = session.query(Component).join(Application, Component.application_id == Application.id)
    if current_user.role == 'viewer' and current_user.team_id:
        query = query.filter(Application.team_id == current_user.team_id)
    
    if team_filter:
        query = query.filter(Application.team_id == int(team_filter))
    if env_filter:
        query = query.filter(Application.environment == env_filter)
    
    components = query.order_by(Application.name, Component.name).all()
    
    # Build workbook
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Compliance Matrix"
    
    # Headers
    headers = ['Application', 'Component', 'Team', 'Environment', 'License Type', 'License Ref (SPDX)']
    for section_name, fields in ASSESSMENT_POINTS:
        for field_key, label in fields:
            headers.append(label)
    headers.extend(['Risk Rating', 'Approval Status', 'Usage Scope', 'Notes'])
    
    header_fill = PatternFill(start_color='1F2937', end_color='1F2937', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF')
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')
    
    # Data rows
    for row_idx, comp in enumerate(components, 2):
        app = comp.application
        row_data = [app.name, comp.name, app.team.name if app.team else '', app.environment]
        
        lic_data = {}
        notes_parts = []
        for lic in comp.licenses:
            if lic.overall_risk_rating:
                lic_data['license_name'] = lic.license_name or ''
                lic_data['spdx_id'] = lic.spdx_id or ''
                for note_field in NOTE_FIELDS:
                    note_value = getattr(lic, note_field, None)
                    if note_value:
                        label = FIELD_LABELS.get(note_field, note_field.replace('_note', ''))
                        notes_parts.append(f"{label}: {note_value}")
                for section_name, fields in ASSESSMENT_POINTS:
                    for field_key, label in fields:
                        lic_data[field_key] = getattr(lic, field_key, None) or ''
                lic_data['risk_rating'] = lic.overall_risk_rating or ''
                lic_data['approval_status'] = lic.approval_status or ''
                lic_data['usage_scope'] = lic.usage_scope or ''
                break
        
        lic_data['notes'] = '\n'.join(notes_parts)
        
        # Apply status filter
        if status_filter:
            if status_filter == 'not_assessed':
                if lic_data.get('overall_risk_rating'):
                    continue
            elif lic_data.get('approval_status') != status_filter:
                continue
        
        # Add license type and ref
        row_data.append(lic_data.get('license_name', ''))
        row_data.append(lic_data.get('spdx_id', ''))
        
        # Add assessment fields
        for section_name, fields in ASSESSMENT_POINTS:
            for field_key, label in fields:
                row_data.append(lic_data.get(field_key, ''))
        
        row_data.append(lic_data.get('risk_rating', ''))
        row_data.append(lic_data.get('approval_status', ''))
        row_data.append(lic_data.get('usage_scope', ''))
        row_data.append(lic_data.get('notes', ''))
        
        for col, value in enumerate(row_data, 1):
            ws.cell(row=row_idx, column=col, value=value)
    
    # Auto-adjust columns
    for col in range(1, len(headers) + 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 15
    
    # Generate response
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    filename = f"compliance_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    response = make_response(output.getvalue())
    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
    response.headers['Content-Type'] = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    
    return response