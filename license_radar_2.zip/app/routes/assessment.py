from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.models import License, Component, AuditLog
from app import Session
from config import Config
from datetime import datetime as dt
import os
import uuid

bp = Blueprint('assessment', __name__, url_prefix='/assessment')

ASSESSMENT_FIELDS = [
    ('Usage Rights', [
        ('internal_use', 'Internal Use Allowed', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('external_use', 'External Use Allowed', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('enterprise_use', 'Enterprise Use Allowed', 'Yes,No,Paid Required,Conditional,Unknown,Needs Legal Review'),
    ]),
    ('Modification & Security', [
        ('source_code_access', 'Source Code Access', 'Full,Partial,None,Unknown'),
        ('modification_allowed', 'Modification Allowed', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('security_fix_allowed', 'Security Fix Allowed', 'Yes,No,Vendor Only,Conditional,Unknown'),
        ('copyleft_requirement', 'Copyleft Requirement', 'None,Weak,Strong,Network Copyleft,Unknown,Needs Legal Review'),
        ('source_disclosure', 'Source Disclosure Required', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
    ]),
    ('Deployment & Distribution', [
        ('redistribution_allowed', 'Redistribution Allowed', 'Yes,No,Conditional,Unknown'),
        ('saas_cloud_use', 'SaaS / Cloud Use Allowed', 'Yes,No,Conditional,Grey Area,Unknown,Needs Legal Review'),
        ('onpremise_deployment', 'On-Prem Deployment Allowed', 'Yes,No,Conditional,Unknown'),
    ]),
    ('Commercial & Legal', [
        ('license_cost', 'License Cost', 'Free,Paid,Freemium,Tiered,Unknown'),
        ('enterprise_license', 'Enterprise License Required', 'Yes,No,Conditional,Unknown,Needs Legal Review'),
        ('legal_risk_level', 'Legal Risk Level', 'Low,Medium,High,Critical,Needs Legal Review'),
        ('compliance_complexity', 'Compliance Complexity', 'Low,Medium,High,Unknown'),
        ('audit_risk', 'Audit Risk', 'Low,Medium,High,Unknown,Needs Legal Review'),
    ]),
    ('Support & Control', [
        ('support_type', 'Support Type', 'Community,Paid Support,Vendor Support,None,Unknown'),
        ('update_control', 'Update Control', 'Full Control,Vendor Controlled,Mixed,Forced Updates,Unknown'),
    ]),
    ('Final Decision', [
        ('overall_risk_rating', 'Overall Risk Rating', 'Low,Medium,High,Critical'),
        ('approval_status', 'Approval Status', 'Approved,Rejected,Conditional,Pending Review,Needs Legal Review'),
        ('usage_scope', 'Usage Scope', 'Internal Only,External Allowed,Enterprise Allowed,Restricted,Not Allowed,Needs Legal Review'),
    ]),
]

def get_field_options(options_str):
    return [opt.strip() for opt in options_str.split(',')]

@bp.route('/<int:license_id>', methods=['GET', 'POST'])
@login_required
def edit(license_id):
    session = Session()
    license = session.query(License).get(license_id)
    
    if not license:
        abort(404)
    
    if current_user.role == 'viewer':
        abort(403)
    
    if request.method == 'POST':
        # Update license information
        license.license_name = request.form.get('license_name', license.license_name)
        license.spdx_id = request.form.get('spdx_id', license.spdx_id)
        
        # Handle file replacement
        new_file = request.files.get('file')
        new_text = request.form.get('license_text', '').strip()
        
        if new_file and new_file.filename:
            ext = new_file.filename.rsplit('.', 1)[-1].lower() if '.' in new_file.filename else ''
            if ext not in Config.ALLOWED_EXTENSIONS:
                flash(f'File type not allowed. Allowed: {", ".join(Config.ALLOWED_EXTENSIONS)}', 'error')
                return redirect(request.url)
            
            # Delete old file if exists
            if license.file_path:
                old_filepath = os.path.join(Config.UPLOAD_FOLDER, license.file_path)
                if os.path.exists(old_filepath):
                    os.remove(old_filepath)
            
            filename = f"{uuid.uuid4()}.{ext}"
            filepath = os.path.join(Config.UPLOAD_FOLDER, filename)
            os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
            new_file.save(filepath)
            
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                license.license_text = f.read()
            license.file_path = filename
        elif new_text:
            license.license_text = new_text
            license.file_path = None
        
        # Update assessment fields
        for section_name, fields in ASSESSMENT_FIELDS:
            for field_key, field_label, options in fields:
                setattr(license, field_key, request.form.get(field_key))
                setattr(license, f'{field_key}_note', request.form.get(f'{field_key}_note'))
        
        license.analysis_status = 'done'
        license.analyzed_at = dt.utcnow()
        
        log = AuditLog(
            user_id=current_user.id,
            action='assessment_complete',
            target_type='license',
            target_id=license.id,
            detail=f'Completed assessment for {license.license_name}',
            ip_address=request.remote_addr
        )
        session.add(log)
        session.commit()
        
        flash('Assessment completed successfully', 'success')
        return redirect(url_for('licenses.detail', id=license_id))
    
    return render_template('assessment/edit.html', 
                        license=license, 
                        fields=ASSESSMENT_FIELDS,
                        get_options=get_field_options,
                        license_data=license.__dict__)

@bp.route('/<int:license_id>/ai', methods=['POST'])
@login_required
def ai_analyze(license_id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    license = session.query(License).get(license_id)
    
    if not license:
        abort(404)
    
    if not license.license_text:
        flash('No license text to analyze', 'error')
        return redirect(url_for('licenses.detail', id=license_id))
    
    from app.services.ai_assessment import run_ai_assessment
    result = run_ai_assessment(license.id)
    
    if result.get('success'):
        flash('AI assessment completed', 'success')
    else:
        flash(f'AI assessment failed: {result.get("error", "Unknown error")}', 'error')
    
    return redirect(url_for('licenses.detail', id=license_id))