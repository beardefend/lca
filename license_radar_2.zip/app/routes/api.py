from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from app.models import Application, Component, License, Clause, Team
from app import Session
from app import csrf
import logging

logger = logging.getLogger(__name__)
from sqlalchemy import func
from datetime import datetime

bp = Blueprint('api', __name__, url_prefix='/api')

@bp.route('/health')
def health():
    return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()}), 200

@bp.route('/dashboard/summary')
@login_required
def dashboard_summary():
    session = Session()
    
    query = session.query(Application)
    if current_user.role == 'viewer' and current_user.team_id:
        query = query.filter(Application.team_id == current_user.team_id)
    
    applications = query.all()
    
    critical = 0
    warning = 0
    cleared = 0
    pending = 0
    
    for app in applications:
        components = app.components
        licenses_loaded = [c.licenses[0] for c in components if c.licenses]
        
        has_critical = False
        has_warning = False
        has_pending = False
        
        for lic in licenses_loaded:
            if lic.analysis_status == 'pending':
                has_pending = True
            for clause in lic.clauses:
                if clause.risk_level == 'critical':
                    has_critical = True
                elif clause.risk_level == 'warning':
                    has_warning = True
        
        if has_critical:
            critical += 1
        elif has_warning:
            warning += 1
        elif has_pending:
            pending += 1
        else:
            cleared += 1
    
    return jsonify({
        'critical': critical,
        'warning': warning,
        'cleared': cleared,
        'pending': pending,
        'total': len(applications)
    })

@bp.route('/clauses/filter')
@login_required
def clauses_filter():
    session = Session()
    
    clause_type = request.args.get('type')
    team_id = request.args.get('team')
    app_id = request.args.get('application')
    
    query = session.query(Clause)
    
    if clause_type:
        query = query.filter(Clause.clause_type == clause_type)
    if team_id:
        query = query.join(License).join(Component).join(Application)
        query = query.filter(Application.team_id == int(team_id))
    if app_id:
        query = query.join(License).join(Component)
        query = query.filter(Component.application_id == int(app_id))
    
    clauses = query.order_by(Clause.risk_level.desc()).limit(100).all()
    
    results = []
    for clause in clauses:
        lic = clause.license
        comp = lic.component
        app = comp.application
        
        results.append({
            'id': clause.id,
            'clause_type': clause.clause_type,
            'clause_title': clause.clause_title,
            'risk_level': clause.risk_level,
            'license': lic.license_name,
            'component': comp.name,
            'application': app.name,
            'team': app.team.name if app.team else None
        })
    
    return jsonify({'clauses': results})

@bp.route('/applications/search')
@login_required
def applications_search():
    query = request.args.get('q', '')
    
    session = Session()
    apps = session.query(Application).filter(Application.name.like(f'%{query}%')).limit(10).all()
    
    results = [{'id': a.id, 'name': a.name, 'team': a.team.name if a.team else None} for a in apps]
    
    return jsonify({'applications': results})

@bp.route('/teams')
@login_required
def teams():
    session = Session()
    teams = session.query(Team).all()
    
    results = [{'id': t.id, 'name': t.name} for t in teams]
    
    return jsonify({'teams': results})

@bp.route('/licenses/list')
@login_required
def licenses_list():
    session = Session()
    
    query = session.query(License).join(Component).join(Application)
    
    if current_user.role == 'viewer' and current_user.team_id:
        query = query.filter(Application.team_id == current_user.team_id)
    elif current_user.role != 'admin':
        if current_user.team_id:
            query = query.filter(Application.team_id == current_user.team_id)
    
    licenses = query.filter(License.license_text != None).filter(License.license_text != '').all()
    
    results = []
    for lic in licenses:
        comp = lic.component
        app = comp.application
        results.append({
            'id': lic.id,
            'license_name': lic.license_name,
            'spdx_id': lic.spdx_id or '',
            'component_name': comp.name,
            'application_name': app.name,
            'display': f"{app.name} / {comp.name} - {lic.license_name} ({lic.spdx_id or 'N/A'})"
        })
    
    return jsonify({'licenses': results})

@bp.route('/research', methods=['POST'])
@login_required
@csrf.exempt
def research():
    if current_user.role != 'admin':
        return jsonify({'answer': 'Access denied', 'sources': []}), 403
    
    data = request.get_json()
    if data is None:
        return jsonify({'answer': 'Invalid JSON in request body', 'sources': []}), 400
    
    query = data.get('query', '') or ''
    if not query:
        return jsonify({'answer': 'No query provided', 'sources': []}), 400
    
    license_id = data.get('license_id')
    provider = data.get('provider')
    model = data.get('model')
    temperature = data.get('temperature')
    max_tokens = data.get('max_tokens')
    system_prompt = data.get('system_prompt')
    ollama_url = data.get('ollama_url')
    
    from app.services.rag_service import answer_with_rag
    
    result = answer_with_rag(
        query,
        license_id=license_id,
        provider=provider,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        system_prompt=system_prompt,
        ollama_url=ollama_url
    )
    
    return jsonify(result)

@bp.route('/ai/status')
@login_required
def ai_status():
    """Get AI provider status."""
    from app.services.ai_service import get_ai_status
    return jsonify(get_ai_status())

@bp.route('/research/index', methods=['POST'])
@login_required
@csrf.exempt
def index_licenses():
    """Index all licenses for RAG search."""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    from app.services.rag_service import embed_license
    from app.models import License
    from app import Session
    
    session = Session()
    licenses = session.query(License).filter(
        License.license_text != None,
        License.license_text != ''
    ).all()
    
    indexed = 0
    for lic in licenses:
        if embed_license(lic.id):
            indexed += 1
    
    session.close()
    
    return jsonify({'success': True, 'indexed': indexed, 'total': len(licenses)})

@bp.route('/test-openrouter', methods=['POST'])
@login_required
@csrf.exempt
def test_openrouter():
    """Test OpenRouter connection with provided credentials."""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Invalid request'}), 400
    
    api_key = data.get('api_key', '').strip()
    model = data.get('model', '').strip()
    
    if not api_key:
        return jsonify({'success': False, 'message': 'API key is required'}), 400
    
    if not model:
        return jsonify({'success': False, 'message': 'Model is required'}), 400
    
    try:
        import requests
        
        # Test with a simple models list request
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:5000',
            'X-Title': 'License Radar'
        }
        
        # First, try to get available models
        response = requests.get(
            'https://openrouter.ai/api/v1/models',
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 401:
            return jsonify({'success': False, 'message': 'Invalid API key'}), 400
        
        if response.status_code != 200:
            return jsonify({'success': False, 'message': f'OpenRouter error: {response.status_code}'}), 400
        
        models_data = response.json()
        available_models = models_data.get('data', [])
        model_ids = [m.get('id') for m in available_models]
        
        # Check if the specified model is available
        if model not in model_ids:
            # Try a more lenient check - partial match
            matching_models = [m for m in model_ids if model.lower() in m.lower()]
            if matching_models:
                return jsonify({
                    'success': True, 
                    'message': "Connection successful! Note: Model '" + model + "' not found directly. Available similar models: " + ", ".join(matching_models[:3])
                }), 200
            return jsonify({
                'success': False, 
                'message': "Model '" + model + "' not found. Available models: " + ", ".join(model_ids[:10]) + "..."
            }), 400
        
        return jsonify({
            'success': True, 
            'message': f'Connection successful! {len(available_models)} models available.'
        }), 200
        
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'message': 'Connection timeout'}), 400
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 400

@bp.route('/assessment/analyze', methods=['POST'])
@login_required
@csrf.exempt
def analyze_assessment():
    """Run AI analysis for 25-point assessment."""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Invalid request'}), 400
    
    license_id = data.get('license_id')
    if not license_id:
        return jsonify({'success': False, 'message': 'License ID is required'}), 400
    
    from app.models import License
    from app import Session
    
    session = Session()
    license = session.query(License).get(license_id)
    
    if not license:
        session.close()
        return jsonify({'success': False, 'message': 'License not found'}), 404
    
    if not license.license_text:
        session.close()
        return jsonify({'success': False, 'message': 'No license text found'}), 400
    
    try:
        # Import and run assessment
        from app.services.ai_assessment import run_ai_assessment_25_points
        logger.info(f"Running AI assessment for license ID: {license_id}")
        result = run_ai_assessment_25_points(license.license_text)
        
        session.close()
        
        if result.get('success'):
            return jsonify(result), 200
        else:
            logger.error(f"AI assessment failed: {result.get('error')}")
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"Assessment endpoint error: {e}")
        session.close()
        return jsonify({'success': False, 'message': str(e)}), 500