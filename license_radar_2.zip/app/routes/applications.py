from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.models import Application, Component, Team, License, AuditLog
from app import Session
from config import Config
import os
import uuid

bp = Blueprint('applications', __name__, url_prefix='/apps')

@bp.route('')
@login_required
def index():
    session = Session()
    query = session.query(Application)
    
    if current_user.role == 'viewer' and current_user.team_id:
        query = query.filter(Application.team_id == current_user.team_id)
    
    applications = query.order_by(Application.name).all()
    teams = session.query(Team).all()
    
    return render_template('applications/index.html', applications=applications, teams=teams)

@bp.route('/new', methods=['GET', 'POST'])
@login_required
def new():
    if current_user.role == 'viewer':
        abort(403)
    
    session = Session()
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        team_id = request.form.get('team_id')
        environment = request.form.get('environment', 'internal')
        
        app = Application(
            name=name,
            description=description,
            team_id=team_id,
            environment=environment,
            created_by=current_user.id
        )
        session.add(app)
        session.commit()
        
        flash(f'Application "{name}" created successfully', 'success')
        return redirect(url_for('applications.index'))
    
    teams = session.query(Team).all()
    return render_template('applications/new.html', teams=teams)

@bp.route('/<int:id>')
@login_required
def detail(id):
    session = Session()
    app = session.query(Application).get(id)
    
    if not app:
        abort(404)
    
    if current_user.role == 'viewer' and current_user.team_id and app.team_id != current_user.team_id:
        abort(403)
    
    # Pre-compute risk and issues for each component
    component_risks = {}
    issues = []
    unassessed = []
    assessment_issues = []
    
    for comp in app.components:
        if comp.licenses:
            highest_risk = 'none'
            lic = comp.licenses[0]  # Use first license
            
            # Check clauses for critical/warning issues
            if lic.clauses:
                for c in lic.clauses:
                    if c.risk_level == 'critical':
                        highest_risk = 'critical'
                        issues.append({
                            'comp_id': comp.id,
                            'comp': comp.name,
                            'lic': lic.license_name,
                            'type': c.clause_type,
                            'risk': c.risk_level,
                            'title': c.clause_title
                        })
                    elif c.risk_level == 'warning' and highest_risk != 'critical':
                        highest_risk = 'warning'
                        issues.append({
                            'comp_id': comp.id,
                            'comp': comp.name,
                            'lic': lic.license_name,
                            'type': c.clause_type,
                            'risk': c.risk_level,
                            'title': c.clause_title
                        })
                    elif c.risk_level == 'info' and highest_risk == 'none':
                        highest_risk = 'info'
            
            # Check 25-point assessment status
            if lic.analysis_status == 'pending':
                highest_risk = 'pending'
                unassessed.append({
                    'comp_id': comp.id,
                    'comp': comp.name,
                    'lic': lic.license_name,
                    'status': 'Pending Analysis'
                })
            elif lic.analysis_status == 'failed':
                highest_risk = 'pending'
                assessment_issues.append({
                    'comp_id': comp.id,
                    'comp': comp.name,
                    'lic': lic.license_name,
                    'issue': 'Analysis Failed'
                })
            elif lic.approval_status in ['Rejected', 'Needs Legal Review']:
                highest_risk = 'critical' if lic.approval_status == 'Rejected' else 'warning'
                assessment_issues.append({
                    'comp_id': comp.id,
                    'comp': comp.name,
                    'lic': lic.license_name,
                    'issue': lic.approval_status,
                    'risk': lic.overall_risk_rating
                })
            elif lic.approval_status == 'Conditional':
                highest_risk = 'warning'
                assessment_issues.append({
                    'comp_id': comp.id,
                    'comp': comp.name,
                    'lic': lic.license_name,
                    'issue': 'Conditional Approval',
                    'risk': lic.overall_risk_rating
                })
            elif not lic.overall_risk_rating and highest_risk == 'none':
                # No assessment completed at all
                unassessed.append({
                    'comp_id': comp.id,
                    'comp': comp.name,
                    'lic': lic.license_name,
                    'status': 'No 25-Point Assessment'
                })
            
            component_risks[comp.id] = highest_risk
        else:
            component_risks[comp.id] = 'pending'
            unassessed.append({
                'comp_id': comp.id,
                'comp': comp.name,
                'lic': 'No license',
                'status': 'No License Uploaded'
            })
    
    return render_template('applications/detail.html', 
                      application=app, 
                      component_risks=component_risks,
                      issues=issues,
                      unassessed=unassessed,
                      assessment_issues=assessment_issues)

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    if current_user.role == 'viewer':
        abort(403)
    
    session = Session()
    app = session.query(Application).get(id)
    
    if not app:
        abort(404)
    
    if request.method == 'POST':
        app.name = request.form.get('name')
        app.description = request.form.get('description')
        app.team_id = request.form.get('team_id')
        app.environment = request.form.get('environment', 'internal')
        session.commit()
        
        flash(f'Application "{app.name}" updated successfully', 'success')
        return redirect(url_for('applications.detail', id=id))
    
    teams = session.query(Team).all()
    return render_template('applications/edit.html', application=app, teams=teams)

@bp.route('/<int:app_id>/components/new', methods=['GET', 'POST'])
@login_required
def new_component(app_id):
    if current_user.role == 'viewer':
        abort(403)
    
    session = Session()
    app = session.query(Application).get(app_id)
    
    if not app:
        abort(404)
    
    if request.method == 'POST':
        name = request.form.get('name')
        version = request.form.get('version')
        vendor = request.form.get('vendor')
        
        component = Component(
            application_id=app_id,
            name=name,
            version=version,
            vendor=vendor
        )
        session.add(component)
        session.commit()
        
        flash(f'Component "{name}" added successfully', 'success')
        return redirect(url_for('applications.detail', id=app_id))
    
    return render_template('applications/new_component.html', application=app)

@bp.route('/<int:app_id>/components/<int:cid>')
@login_required
def component_detail(app_id, cid):
    session = Session()
    component = session.query(Component).get(cid)
    
    if not component or component.application_id != app_id:
        abort(404)
    
    return render_template('applications/component_detail.html', application=component.application, component=component)

@bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    if current_user.role == 'viewer':
        abort(403)
    
    session = Session()
    app = session.query(Application).get(id)
    
    if not app:
        abort(404)
    
    app_name = app.name
    session.delete(app)
    session.commit()
    
    flash(f'Application "{app_name}" deleted successfully', 'success')
    return redirect(url_for('applications.index'))

@bp.route('/<int:app_id>/components/<int:cid>/delete', methods=['POST'])
@login_required
def delete_component(app_id, cid):
    if current_user.role == 'viewer':
        abort(403)
    
    session = Session()
    component = session.query(Component).get(cid)
    
    if not component or component.application_id != app_id:
        abort(404)
    
    comp_name = component.name
    session.delete(component)
    session.commit()
    
    flash(f'Component "{comp_name}" deleted successfully', 'success')
    return redirect(url_for('applications.detail', id=app_id))