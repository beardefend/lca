from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import login_required, current_user
from app.models import User, Team, License, AuditLog, Settings
from app import Session
from config import Config
import bcrypt

bp = Blueprint('admin', __name__, url_prefix='/admin')

@bp.route('')
@login_required
def index():
    if current_user.role != 'admin':
        abort(403)
    return render_template('admin/index.html')

@bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    
    if request.method == 'POST':
        # Save OpenRouter API Key
        openrouter_api_key = request.form.get('openrouter_api_key', '').strip()
        if openrouter_api_key:
            setting = session.query(Settings).filter_by(key='openrouter_api_key').first()
            if not setting:
                setting = Settings(key='openrouter_api_key', value=openrouter_api_key)
                session.add(setting)
            else:
                setting.value = openrouter_api_key
        
        # Save OpenRouter Model
        openrouter_model = request.form.get('openrouter_model', '').strip()
        if openrouter_model:
            setting = session.query(Settings).filter_by(key='openrouter_model').first()
            if not setting:
                setting = Settings(key='openrouter_model', value=openrouter_model)
                session.add(setting)
            else:
                setting.value = openrouter_model
        
        # Save Ollama URL
        ollama_url = request.form.get('ollama_url', '').strip()
        if ollama_url:
            setting = session.query(Settings).filter_by(key='ollama_url').first()
            if not setting:
                setting = Settings(key='ollama_url', value=ollama_url)
                session.add(setting)
            else:
                setting.value = ollama_url
        
        # Save Ollama Model
        ollama_model = request.form.get('ollama_model', '').strip()
        if ollama_model:
            setting = session.query(Settings).filter_by(key='ollama_model').first()
            if not setting:
                setting = Settings(key='ollama_model', value=ollama_model)
                session.add(setting)
            else:
                setting.value = ollama_model
        
        # Save AI Analysis Enabled
        ai_enabled = request.form.get('ai_analysis_enabled', 'true') == 'true'
        setting = session.query(Settings).filter_by(key='ai_analysis_enabled').first()
        if not setting:
            setting = Settings(key='ai_analysis_enabled', value=str(ai_enabled).lower())
            session.add(setting)
        else:
            setting.value = str(ai_enabled).lower()
        
        session.commit()
        flash('Settings saved successfully', 'success')
        return redirect(url_for('admin.settings'))
    
    # Load current settings from database, fallback to Config
    settings = {s.key: s.value for s in session.query(Settings).all()}
    
    openrouter_api_key = settings.get('openrouter_api_key', '')
    openrouter_model = settings.get('openrouter_model', Config.OPENROUTER_MODEL)
    ollama_url = settings.get('ollama_url', Config.OLLAMA_BASE_URL)
    ollama_model = settings.get('ollama_model', Config.OLLAMA_MODEL)
    ai_analysis_enabled = settings.get('ai_analysis_enabled', 'true') == 'true'
    
    # Get AI status
    from app.services.ai_service import get_ai_status
    ai_status = get_ai_status()
    
    return render_template('admin/settings.html', 
                         openrouter_api_key=openrouter_api_key,
                         openrouter_model=openrouter_model,
                         ollama_url=ollama_url,
                         ollama_model=ollama_model,
                         ai_analysis_enabled=ai_analysis_enabled,
                         ai_status=ai_status)

@bp.route('/settings/reset', methods=['POST'])
@login_required
def reset_settings():
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    
    # Keys to reset
    keys_to_reset = ['openrouter_api_key', 'openrouter_model', 'ollama_url', 'ollama_model']
    
    for key in keys_to_reset:
        setting = session.query(Settings).filter_by(key=key).first()
        if setting:
            session.delete(setting)
    
    session.commit()
    flash('AI credentials reset to default values', 'success')
    return redirect(url_for('admin.settings'))

@bp.route('/users')
@login_required
def users():
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    users = session.query(User).all()
    teams = session.query(Team).all()
    
    return render_template('admin/users.html', users=users, teams=teams)

@bp.route('/users/new', methods=['GET', 'POST'])
@login_required
def new_user():
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role', 'viewer')
        team_id = request.form.get('team_id') or None
        
        pw_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        user = User(
            username=username,
            email=email,
            password_hash=pw_hash,
            role=role,
            team_id=team_id
        )
        session.add(user)
        
        log = AuditLog(
            user_id=current_user.id,
            action='user_create',
            target_type='user',
            target_id=user.id,
            detail=f'Created user {username} with role {role}',
            ip_address=request.remote_addr
        )
        session.add(log)
        session.commit()
        
        flash(f'User "{username}" created successfully', 'success')
        return redirect(url_for('admin.users'))
    
    teams = session.query(Team).all()
    return render_template('admin/new_user.html', teams=teams)

@bp.route('/users/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_user(id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    user = session.query(User).get(id)
    
    if not user:
        abort(404)
    
    if request.method == 'POST':
        user.username = request.form.get('username')
        user.email = request.form.get('email')
        user.role = request.form.get('role', 'viewer')
        team_id = request.form.get('team_id')
        user.team_id = int(team_id) if team_id else None
        
        new_password = request.form.get('password')
        if new_password:
            user.password_hash = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        log = AuditLog(
            user_id=current_user.id,
            action='user_edit',
            target_type='user',
            target_id=user.id,
            detail=f'Edited user {user.username}',
            ip_address=request.remote_addr
        )
        session.add(log)
        session.commit()
        
        flash(f'User "{user.username}" updated successfully', 'success')
        return redirect(url_for('admin.users'))
    
    teams = session.query(Team).all()
    return render_template('admin/edit_user.html', user=user, teams=teams)

@bp.route('/users/<int:id>/deactivate', methods=['POST'])
@login_required
def deactivate_user(id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    user = session.query(User).get(id)
    
    if not user:
        abort(404)
    
    user.is_active = False
    
    log = AuditLog(
        user_id=current_user.id,
        action='user_deactivate',
        target_type='user',
        target_id=user.id,
        detail=f'Deactivated user {user.username}',
        ip_address=request.remote_addr
    )
    session.add(log)
    session.commit()
    
    flash(f'User "{user.username}" deactivated', 'success')
    return redirect(url_for('admin.users'))

@bp.route('/users/<int:id>/reactivate', methods=['POST'])
@login_required
def reactivate_user(id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    user = session.query(User).get(id)
    
    if not user:
        abort(404)
    
    user.is_active = True
    
    log = AuditLog(
        user_id=current_user.id,
        action='user_reactivate',
        target_type='user',
        target_id=user.id,
        detail=f'Reactivated user {user.username}',
        ip_address=request.remote_addr
    )
    session.add(log)
    session.commit()
    
    flash(f'User "{user.username}" reactivated', 'success')
    return redirect(url_for('admin.users'))

@bp.route('/users/<int:id>/delete', methods=['POST'])
@login_required
def delete_user(id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    user = session.query(User).get(id)
    
    if not user:
        abort(404)
    
    if user.id == current_user.id:
        flash('You cannot delete yourself', 'error')
        return redirect(url_for('admin.users'))
    
    username = user.username
    session.delete(user)
    
    log = AuditLog(
        user_id=current_user.id,
        action='user_delete',
        target_type='user',
        target_id=user.id,
        detail=f'Deleted user {username}',
        ip_address=request.remote_addr
    )
    session.add(log)
    session.commit()
    
    flash(f'User "{username}" deleted permanently', 'success')
    return redirect(url_for('admin.users'))

@bp.route('/teams', methods=['GET', 'POST'])
@login_required
def teams():
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        team = Team(name=name, description=description)
        session.add(team)
        session.commit()
        
        flash(f'Team "{name}" created successfully', 'success')
        return redirect(url_for('admin.teams'))
    
    teams = session.query(Team).all()
    return render_template('admin/teams.html', teams=teams)

@bp.route('/teams/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_team(id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    team = session.query(Team).get(id)
    
    if not team:
        abort(404)
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        existing = session.query(Team).filter(Team.name == name, Team.id != id).first()
        if existing:
            flash(f'Team name "{name}" already exists', 'error')
            return redirect(url_for('admin.edit_team', id=id))
        
        team.name = name
        team.description = description
        session.commit()
        
        log = AuditLog(
            user_id=current_user.id,
            action='team_update',
            target_type='team',
            target_id=team.id,
            detail=f'Updated team "{team.name}"',
            ip_address=request.remote_addr
        )
        session.add(log)
        session.commit()
        
        flash(f'Team "{team.name}" updated successfully', 'success')
        return redirect(url_for('admin.teams'))
    
    return render_template('admin/edit_team.html', team=team)

@bp.route('/teams/<int:id>/delete', methods=['POST'])
@login_required
def delete_team(id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    team = session.query(Team).get(id)
    
    if not team:
        abort(404)
    
    if team.applications:
        flash(f'Cannot delete team "{team.name}" - it has associated applications', 'error')
        return redirect(url_for('admin.teams'))
    
    team_name = team.name
    session.delete(team)
    session.commit()
    
    flash(f'Team "{team_name}" deleted successfully', 'success')
    return redirect(url_for('admin.teams'))

@bp.route('/research')
@login_required
def research():
    if current_user.role != 'admin':
        abort(403)
    return render_template('admin/research.html')

@bp.route('/analyze/<int:license_id>', methods=['POST'])
@login_required
def analyze(license_id):
    if current_user.role != 'admin':
        abort(403)
    
    session = Session()
    license = session.query(License).get(license_id)
    
    if not license:
        abort(404)
    
    if not Config.AI_ANALYSIS_ENABLED:
        license.analysis_status = 'failed'
        session.commit()
        flash('AI analysis is currently disabled', 'warning')
        return redirect(url_for('licenses.detail', id=license_id))
    
    provider = request.form.get('provider', None)  # openrouter or ollama
    
    from app.services.ai_service import analyze_license
    
    result = analyze_license(license.id, provider=provider)
    
    provider_name = result.get('provider', 'AI').title()
    
    if result['success']:
        license.analysis_status = 'done'
        session.commit()
        
        log = AuditLog(
            user_id=current_user.id,
            action='license_analyze',
            target_type='license',
            target_id=license.id,
            detail=f'Analyzed license {license.license_name} using {provider_name}',
            ip_address=request.remote_addr
        )
        session.add(log)
        session.commit()
        
        flash(f'License analyzed successfully using {provider_name}', 'success')
    else:
        license.analysis_status = 'failed'
        session.commit()
        flash(f'Analysis failed: {result.get("error", "Unknown error")}', 'error')
    
    return redirect(url_for('licenses.detail', id=license_id))