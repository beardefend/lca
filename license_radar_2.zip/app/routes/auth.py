from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_user, logout_user, login_required, current_user
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from app.models import Base, User, AuditLog
from app import Session, limiter
from config import Config
import bcrypt
from datetime import datetime
from wtforms import StringField, PasswordField, BooleanField
from wtforms.validators import DataRequired, Email, Length, EqualTo
from flask_wtf import FlaskForm

bp = Blueprint('auth', __name__, url_prefix='/auth')

limiter.limit(Config.LOGIN_RATE_LIMIT)

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Device')

class ChangePasswordForm(FlaskForm):
    current_password = PasswordField('Current Password', validators=[DataRequired()])
    new_password = PasswordField('New Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm New Password', validators=[DataRequired(), EqualTo('new_password')])

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        session = Session()
        user = session.query(User).filter_by(username=form.username.data).first()
        
        if user and user.is_active and bcrypt.checkpw(form.password.data.encode('utf-8'), user.password_hash.encode('utf-8')):
            login_user(user, remember=form.remember.data)
            user.last_login = datetime.utcnow()
            session.commit()
            
            log = AuditLog(
                user_id=user.id,
                action='login',
                detail='User logged in',
                ip_address=request.remote_addr
            )
            session.add(log)
            session.commit()
            
            next_page = request.args.get('next')
            flash('Welcome back!', 'success')
            return redirect(next_page or url_for('dashboard.index'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('auth/login.html', form=form)

@bp.route('/logout')
@login_required
def logout():
    session = Session()
    log = AuditLog(
        user_id=current_user.id,
        action='logout',
        detail='User logged out',
        ip_address=request.remote_addr
    )
    session.add(log)
    session.commit()
    
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('auth.login'))

@bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        session = Session()
        user = session.query(User).get(current_user.id)
        
        if bcrypt.checkpw(form.current_password.data.encode('utf-8'), user.password_hash.encode('utf-8')):
            user.password_hash = bcrypt.hashpw(form.new_password.data.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
            
            log = AuditLog(
                user_id=user.id,
                action='change_password',
                detail='Password changed',
                ip_address=request.remote_addr
            )
            session.add(log)
            session.commit()
            
            flash('Password updated successfully', 'success')
            return redirect(url_for('dashboard.index'))
        else:
            flash('Current password is incorrect', 'error')
    
    return render_template('auth/change_password.html', form=form)