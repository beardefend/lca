from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, send_from_directory
from flask_login import login_required, current_user
from app.models import License, Component, AuditLog
from app import Session
from config import Config
import os
import uuid

bp = Blueprint('licenses', __name__, url_prefix='/licenses')

@bp.route('/upload/<int:component_id>', methods=['GET', 'POST'])
@login_required
def upload(component_id):
    if current_user.role == 'viewer':
        abort(403)
    
    session = Session()
    component = session.query(Component).get(component_id)
    
    if not component:
        abort(404)
    
    if request.method == 'POST':
        license_text = ''
        filename = ''
        license_name = request.form.get('license_name', 'Untitled License')
        
        # Check for pasted text first
        pasted_text = request.form.get('license_text', '').strip()
        if pasted_text:
            license_text = pasted_text
            ext = 'txt'
        # Otherwise check for file upload
        elif 'file' in request.files:
            file = request.files['file']
            if file.filename == '':
                flash('No file selected', 'error')
                return redirect(request.url)
            
            ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
            if ext not in Config.ALLOWED_EXTENSIONS:
                flash(f'File type not allowed. Allowed: {", ".join(Config.ALLOWED_EXTENSIONS)}', 'error')
                return redirect(request.url)
            
            # Use file name if no license_name provided
            if not request.form.get('license_name'):
                license_name = file.filename.rsplit('.', 1)[0]
            
            filename = f"{uuid.uuid4()}.{ext}"
            filepath = os.path.join(Config.UPLOAD_FOLDER, filename)
            os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
            file.save(filepath)
            
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                license_text = f.read()
        else:
            flash('Please provide either a file or paste license text', 'error')
            return redirect(request.url)
        
        spdx_id = request.form.get('spdx_id', '')
        
        license = License(
            component_id=component_id,
            license_name=license_name,
            spdx_id=spdx_id,
            license_text=license_text,
            file_path=filename,
            analysis_status='pending'
        )
        session.add(license)
        
        log = AuditLog(
            user_id=current_user.id,
            action='license_upload',
            target_type='license',
            detail=f'License uploaded for component {component.name}',
            ip_address=request.remote_addr
        )
        session.add(log)
        session.commit()
        
        flash('License uploaded successfully. Please complete the 25-point assessment.', 'success')
        return redirect(url_for('assessment.edit', license_id=license.id))
    
    return render_template('licenses/upload.html', component=component)

@bp.route('/<int:id>')
@login_required
def detail(id):
    session = Session()
    license = session.query(License).get(id)
    
    if not license:
        abort(404)
    
    # Redirect to assessment - that's where all the 25-point data is now
    return redirect(url_for('assessment.edit', license_id=id))

@bp.route('/download/')
@login_required
def download(filename):
    return send_from_directory(Config.UPLOAD_FOLDER, filename)
