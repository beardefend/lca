from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app.models import Application, Component, License, Clause, Team
from app import Session
from sqlalchemy import func, or_

bp = Blueprint('dashboard', __name__)

@bp.route('/')
@login_required
def index():
    session = Session()
    
    query = session.query(Application)
    
    if current_user.role == 'viewer' and current_user.team_id:
        query = query.filter(Application.team_id == current_user.team_id)
    
    applications = query.all()
    
    # Get filter values
    team_filter = request.args.get('team')
    env_filter = request.args.get('environment')
    risk_filter = request.args.get('risk')
    
    critical_apps = []
    warning_apps = []
    cleared_apps = []
    pending_review = []
    
    for app in applications:
        components = app.components
        
        highest_risk = 'cleared'
        has_critical = False
        has_warning = False
        has_pending = False
        
        # Check licenses using 25-point assessment fields
        for comp in components:
            if comp.licenses:
                lic = comp.licenses[0]  # Use first license
                risk = lic.overall_risk_rating
                status = lic.approval_status
                
                if risk in ['Critical', 'High'] or status == 'Rejected' or status == 'Needs Legal Review':
                    has_critical = True
                elif risk in ['Medium'] or status in ['Pending Review', 'Conditional']:
                    has_warning = True
                elif not risk or not status:
                    has_pending = True
        
        if has_critical:
            highest_risk = 'critical'
            critical_apps.append(app)
        elif has_warning:
            highest_risk = 'warning'
            warning_apps.append(app)
        elif has_pending:
            highest_risk = 'pending'
            pending_review.append(app)
        else:
            cleared_apps.append(app)
    
    teams = session.query(Team).all()
    
    # Build app_data for table
    app_data = []
    for app in applications:
        components = app.components
        licenses_loaded = [c.licenses[0] for c in components if c.licenses]
        
        highest_risk = 'cleared'
        has_critical = False
        has_warning = False
        has_pending = False
        
        for comp in components:
            if comp.licenses:
                lic = comp.licenses[0]
                risk = lic.overall_risk_rating
                status = lic.approval_status
                
                if risk in ['Critical', 'High'] or status == 'Rejected' or status == 'Needs Legal Review':
                    has_critical = True
                elif risk in ['Medium'] or status in ['Pending Review', 'Conditional']:
                    has_warning = True
                elif not risk or not status:
                    has_pending = True
        
        if has_critical:
            highest_risk = 'critical'
        elif has_warning:
            highest_risk = 'warning'
        elif has_pending:
            highest_risk = 'pending'
        else:
            highest_risk = 'cleared'
        
        app_data.append({
            'app': app,
            'team': app.team,
            'environment': app.environment,
            'component_count': len(components),
            'highest_risk': highest_risk,
            'license_count': len(licenses_loaded),
            'has_clauses': any(len(lic.clauses) > 0 for lic in licenses_loaded)
        })
    
    # Apply filters to app_data
    if team_filter:
        app_data = [d for d in app_data if d['team'] and d['team'].id == int(team_filter)]
    if env_filter:
        app_data = [d for d in app_data if d['environment'] == env_filter]
    if risk_filter:
        app_data = [d for d in app_data if d['highest_risk'] == risk_filter]
    
    # Filter counts when filters active
    if team_filter or env_filter or risk_filter:
        critical_count = len([d for d in app_data if d['highest_risk'] == 'critical'])
        warning_count = len([d for d in app_data if d['highest_risk'] == 'warning'])
        cleared_count = len([d for d in app_data if d['highest_risk'] == 'cleared'])
        pending_count = len([d for d in app_data if d['highest_risk'] == 'pending'])
    else:
        critical_count = len(critical_apps)
        warning_count = len(warning_apps)
        cleared_count = len(cleared_apps)
        pending_count = len(pending_review)
    
    return render_template('dashboard/index.html',
                   critical_count=critical_count,
                   warning_count=warning_count,
                   cleared_count=cleared_count,
                   pending_count=pending_count,
                   applications=app_data,
                   teams=teams,
                   team_filter=team_filter,
                   env_filter=env_filter,
                   risk_filter=risk_filter)