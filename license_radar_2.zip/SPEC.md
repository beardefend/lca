# License Radar — Project Specification

## What this application does
License Radar is an internal web application for a bank to track software licenses
across all running applications, identify critical license clauses, and understand
compliance risk across teams. It maps the hierarchy:

**Team → Application → Component → License → Clauses**

Example: "Application Development" team owns "Loan Management System" which uses
nginx (MIT) and Tomcat (Apache 2.0). Each license has clauses extracted and flagged
by risk category.

---

## Tech Stack

| Layer | Choice | Reason |
|-------|--------|--------|
| Language | Python 3.11 | Stable, readable |
| Web framework | Flask | Simple, minimal, easy to maintain |
| Templates | Jinja2 (server-rendered HTML) | No JS framework needed |
| Database | SQLite via SQLAlchemy ORM | Zero admin, single file, easy backup |
| Auth | Flask-Login + bcrypt | Session-based, no OAuth complexity |
| CSRF | Flask-WTF | One decorator per form |
| LLM runtime | Ollama (REST API at localhost:11434) | CPU-only, local, no GPU needed |
| LLM model | qwen2.5:14b-instruct-q4_K_M | Best reasoning on CPU at this size |
| Vector store | ChromaDB (embedded) | No separate process, runs in-process |
| Rate limiting | Flask-Limiter | Protects login endpoint |
| Security headers | Flask-Talisman | CSP, HSTS, X-Frame-Options |
| Deployment | Docker Compose | Single command deploy |
| Styling | Plain CSS (custom design system) | No framework dependency |

---

## Project Structure

```
license-radar/
├── app/
│   ├── __init__.py          # Flask app factory, extensions init
│   ├── models.py            # ALL SQLAlchemy models in one file
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── auth.py          # login, logout, change password
│   │   ├── dashboard.py     # main dashboard view
│   │   ├── applications.py  # CRUD for applications and components
│   │   ├── licenses.py      # license upload, view, clause detail
│   │   ├── admin.py         # user management, team management, AI console
│   │   └── api.py           # internal JSON endpoints for dynamic UI
│   ├── services/
│   │   ├── ai_service.py    # calls Ollama, extracts clauses from license text
│   │   ├── rag_service.py   # ChromaDB embed + query for research console
│   │   └── clause_service.py # clause taxonomy, risk categorisation logic
│   ├── templates/
│   │   ├── base.html        # base layout with nav
│   │   ├── auth/
│   │   ├── dashboard/
│   │   ├── applications/
│   │   ├── licenses/
│   │   └── admin/
│   ├── static/
│   │   ├── css/
│   │   │   └── main.css     # all styles in one file
│   │   └── js/
│   │       └── main.js      # minimal vanilla JS only
│   └── utils.py             # shared helpers (file validation, pagination, etc.)
├── uploads/                 # license files stored here (outside web root logic)
├── data/                    # SQLite db file and ChromaDB persist directory
├── .env                     # all environment variables
├── .env.example             # template with no secrets
├── config.py                # reads .env, defines Config class
├── run.py                   # entrypoint
├── requirements.txt
├── Dockerfile
└── docker-compose.yml
```

---

## Data Models (models.py)

### User
```
id, username, email, password_hash, role (admin/analyst/viewer),
team_id (nullable — null means global access), is_active,
created_at, last_login
```

### Team
```
id, name, description, created_at
```

### Application
```
id, name, description, team_id, environment (internal/external/both),
created_at, updated_at, created_by
```

### Component
```
id, application_id, name, version, vendor, created_at
```

### License
```
id, component_id, spdx_id (e.g. "Apache-2.0"), license_name,
license_text (full text), file_path, analysis_status (pending/done/failed),
analyzed_at, created_at
```

### Clause
```
id, license_id, clause_type, clause_title, clause_text (extracted snippet),
risk_level (critical/warning/info), deployment_scope (internal/external/both),
ai_explanation, created_at
```

### Clause types (fixed taxonomy):
- copyleft
- network_use
- patent
- commercial_restriction
- trademark
- attribution
- warranty_liability
- export_control
- data_processing

### AuditLog
```
id, user_id, action, target_type, target_id, detail, timestamp, ip_address
```

---

## User Roles

| Role | Can do |
|------|--------|
| admin | Everything — manage users, teams, apps, licenses, run AI analysis, access research console |
| analyst | Add/edit applications and components, upload licenses, view all, add notes — NO AI console |
| viewer | Read-only. Scoped to their team (if team_id set) or global (if team_id null) |

Viewers with a team_id set can ONLY see applications belonging to that team.
Viewers with no team_id (global viewers) can see everything but cannot edit.

---

## Route Map

### Auth (/auth)
- GET/POST /auth/login
- GET /auth/logout
- GET/POST /auth/change-password

### Dashboard (/)
- GET / — main dashboard

### Applications (/apps)
- GET /apps — list all applications (filtered by team for scoped viewers)
- GET/POST /apps/new — create application
- GET /apps/<id> — application detail with component list
- GET/POST /apps/<id>/edit — edit application
- GET/POST /apps/<id>/components/new — add component
- GET /apps/<id>/components/<cid> — component detail with license info

### Licenses (/licenses)
- GET/POST /licenses/upload/<component_id> — upload license file
- GET /licenses/<id> — license detail with all clauses
- GET /licenses/<id>/clauses — clause list for a license

### Admin (/admin) — admin role only
- GET /admin — admin panel overview
- GET/POST /admin/users — user list and create
- GET/POST /admin/users/<id>/edit — edit user
- POST /admin/users/<id>/deactivate
- GET/POST /admin/teams — team list and create
- GET /admin/research — AI research console (RAG Q&A)
- POST /admin/analyze/<license_id> — trigger AI analysis on a license

### API (/api) — internal use only
- GET /api/dashboard/summary — risk counts for dashboard cards
- GET /api/clauses/filter — filtered clause view (by team/app/license/type)
- GET /api/applications/search — search for autocomplete

---

## Dashboard Design

The dashboard has four sections:

### 1. Risk summary bar (top)
Four status cards across the top:
- Critical risk — applications with at least one critical clause
- Needs review — applications with warning-level clauses only
- Cleared — applications with only info-level clauses
- Pending analysis — components with uploaded licenses not yet analyzed

### 2. Filters bar
Dropdowns to filter the application list:
- Team
- Environment (internal / external / both)
- Risk level (critical / warning / cleared / pending)
- Clause type (copyleft / patent / commercial / etc.)

### 3. Application table
Columns: Application name | Team | Environment | Components | Highest risk | Clause flags
Clicking an application opens the application detail page.
Risk is shown as a coloured pill (red/amber/green/grey) — NO numerical scores.

### 4. Clause cross-reference panel
A separate tab on the dashboard showing clauses grouped by:
- By clause type (e.g. all copyleft clauses across all apps)
- By team (e.g. all critical clauses owned by Network Services)
Each row links to the application and license it came from.

---

## AI Analysis Flow (admin only — invisible to viewers)

1. Admin uploads a license file (.txt, .md, .pdf) for a component.
2. System stores the file, sets analysis_status = "pending".
3. Admin clicks "Run Analysis" on the license page (or it can be set to auto-trigger).
4. Backend calls ai_service.py which sends the license text to Ollama.
5. Ollama runs Qwen 2.5 14B and returns structured JSON with extracted clauses.
6. Clauses are saved to the Clause table linked to that license.
7. License analysis_status is set to "done".
8. The dashboard now reflects the risk flags — no mention of AI anywhere in the UI.

The "Run Analysis" button is only visible to admin users.
All AI-related routes are under /admin and protected by role check.
No labels, tooltips, or text anywhere in the viewer UI that suggests AI was involved.

---

## RAG Research Console (admin only)

Located at /admin/research. Looks like a simple Q&A interface.
Label it "License Research Console" — no AI/LLM branding.

How it works:
- On license analysis completion, the full license text is embedded into ChromaDB.
- When admin submits a query, rag_service.py retrieves the top-k relevant chunks.
- The chunks + query are sent to Ollama for a grounded answer.
- Answer is displayed with source references (which license/application it came from).

Example queries it should handle well:
- "Which applications have AGPL components deployed externally?"
- "Show me all patent termination clauses across ADC team applications"
- "What are the attribution obligations for the LMS application?"

---

## .env Variables

```env
# Flask
SECRET_KEY=change-this-to-a-long-random-string
FLASK_ENV=production
DEBUG=false

# Database
DATABASE_PATH=./data/licenseradar.db

# File uploads
UPLOAD_FOLDER=./uploads
MAX_UPLOAD_SIZE_MB=10
ALLOWED_EXTENSIONS=txt,md,pdf

# Ollama
OLLAMA_BASE_URL=http://ollama:11434
OLLAMA_MODEL=qwen2.5:14b-instruct-q4_K_M
OLLAMA_TIMEOUT_SECONDS=120

# ChromaDB
CHROMA_PERSIST_DIR=./data/chroma

# AI feature flag
AI_ANALYSIS_ENABLED=true

# Security
SESSION_COOKIE_SECURE=true
SESSION_COOKIE_HTTPONLY=true
SESSION_COOKIE_SAMESITE=Strict
PERMANENT_SESSION_LIFETIME_DAYS=1
LOGIN_RATE_LIMIT=10 per minute

# First admin (only used on first run to seed the admin account)
INITIAL_ADMIN_USERNAME=admin
INITIAL_ADMIN_EMAIL=admin@bank.local
INITIAL_ADMIN_PASSWORD=change-this-immediately
```

---

## Security Requirements

Every one of these must be implemented:

1. All passwords hashed with bcrypt (never stored plaintext)
2. CSRF token on every POST form via Flask-WTF
3. All routes except /auth/login require @login_required
4. Admin routes additionally require role == "admin" check
5. Viewer routes filter queryset by team_id if set
6. File uploads: validate extension (whitelist), validate MIME type, max size enforced, saved with UUID filename (not original name), stored in /uploads outside static folder
7. SQLAlchemy ORM for all queries — no raw SQL string formatting
8. Flask-Talisman for security headers (CSP, HSTS, X-Frame-Options: DENY, X-Content-Type-Options)
9. Flask-Limiter: 10 per minute on /auth/login
10. No SECRET_KEY, passwords, or credentials in source code — all via .env
11. DEBUG=false in production
12. AuditLog entry written for: login, logout, user create/edit/deactivate, license upload, analysis trigger
13. Session lifetime: 1 day, configurable via .env

---

## Styling Guidelines

Modern, clean, professional. Dark sidebar navigation. Light content area.
No CSS framework — pure custom CSS.

Design tokens to define at top of main.css:
```css
--color-bg: #f8f9fa;
--color-surface: #ffffff;
--color-sidebar: #1a1d23;
--color-sidebar-text: #a0aec0;
--color-sidebar-active: #ffffff;
--color-primary: #3b82f6;
--color-critical: #ef4444;
--color-warning: #f59e0b;
--color-cleared: #22c55e;
--color-pending: #6b7280;
--color-border: #e5e7eb;
--color-text-primary: #111827;
--color-text-secondary: #6b7280;
--font-sans: 'Inter', system-ui, sans-serif;
--radius: 8px;
--shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
```

Load Inter font from a self-hosted woff2 file (no Google Fonts CDN — bank environment).
Or fall back to system-ui if self-hosting is not set up.

Layout: fixed sidebar (240px) + main content area. Responsive to collapse sidebar on small screens.

---

## Docker Compose

Three services:
1. `app` — Flask application
2. `ollama` — Ollama LLM runtime
3. (ChromaDB runs embedded inside the app container — no separate service needed)

The `app` service mounts `./data` and `./uploads` as volumes for persistence.
The `ollama` service mounts `./ollama-models` as a volume so models survive container restarts.

On first start, a startup script should:
1. Run database migrations (Flask-Migrate or just db.create_all())
2. Seed the initial admin account from .env if no users exist
3. Pull the Ollama model if not already present

---

## What NOT to build (keep it simple)

- No email notifications
- No API tokens or external integrations
- No charts or graphs (pills and counts are enough)
- No real-time websockets
- No multi-file bulk upload in v1 (single file per component)
- No password reset via email (admin resets passwords manually)
- No dark mode toggle
- No export to PDF/Excel in v1
- No celery/task queue — AI analysis runs synchronously on trigger

---

## Definition of Done

The application is complete when:
- [ ] Login/logout works with rate limiting
- [ ] Admin can create teams, users, applications, components
- [ ] Admin can upload a license file and trigger analysis
- [ ] Clauses are extracted and stored with risk level
- [ ] Dashboard shows applications with risk pills and filters work
- [ ] Clause cross-reference view works (filter by team/app/clause type)
- [ ] Application detail page shows component → license → clause drill-down
- [ ] RAG research console answers questions about stored licenses
- [ ] Viewer accounts are restricted by team scope
- [ ] All security requirements are implemented
- [ ] Docker Compose brings up the full stack with one command
- [ ] .env.example documents every variable
