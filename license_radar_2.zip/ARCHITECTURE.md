# License Radar — Architecture & Decisions

## Why these choices were made

### SQLite over PostgreSQL
At hundreds of applications with light concurrent usage (internal bank tool),
SQLite is perfectly capable. Benefits: zero administration, single file backup,
no separate container, no connection string complexity. Migrate to PostgreSQL
later with Flask-Migrate if needed.

### Flask over FastAPI
FastAPI is excellent but adds async complexity and Pydantic models that make
the codebase harder to read for someone maintaining it. Flask is synchronous,
explicit, and every file does one obvious thing. For a bank internal tool with
no high-throughput requirements, Flask is the right call.

### Jinja2 over React
The person maintaining this application is not a React developer. Server-rendered
HTML with Jinja2 means the entire application logic is in Python — one language,
one mental model. The UI is fast (no JS bundle load), works without JavaScript
for basic views, and is easy to debug.

### Qwen 2.5 14B Q4 over Gemma
Qwen 2.5 at the 14B Q4 quantization level has stronger instruction-following
and structured JSON output than Gemma 4 at equivalent size. For the clause
extraction task (must return valid JSON schema), consistent structured output
is more important than raw reasoning speed. Qwen 2.5 14B Q4 fits in 10-12GB
RAM. If server RAM is limited to 8GB, drop to qwen2.5:7b-instruct-q4_K_M.

### ChromaDB embedded over Qdrant
Qdrant requires a separate Docker container and a client library. ChromaDB
can run embedded (in-process, no network calls) and persists to a local directory.
For the RAG research console with one admin user querying occasionally, embedded
ChromaDB is ideal. No separate service to manage.

### Synchronous AI analysis over Celery
Adding Celery requires Redis, a worker process, and significantly more
infrastructure. Since AI analysis is only triggered by an admin and the
license files are small, a synchronous request with a loading indicator
(and a generous timeout in .env) is simpler and more maintainable.
The tradeoff is that the analysis page will appear to hang for 30-120 seconds
while Ollama processes — this is acceptable for an internal tool.

### No bulk upload in v1
Bulk upload adds file parsing complexity (zip extraction, mapping filenames
to components). The spec calls for simplicity and fast delivery. Manual
one-by-one upload is sufficient for the initial data load and can be added
in v2.

---

## Risk flags and what they mean in a banking context

| Clause Type | Risk Level | Why it matters for a bank |
|-------------|-----------|--------------------------|
| AGPL (network use) | Critical | If exposed over network, source must be released — violates IP policy |
| GPL copyleft | Critical | Any linked code must also be GPL — affects proprietary banking software |
| Commercial restriction | Critical | Some licenses prohibit commercial use entirely |
| Patent termination | Warning | Grant terminates if you sue for patents — significant for a bank |
| LGPL copyleft | Warning | Weaker copyleft but still requires attention if statically linked |
| Trademark restriction | Warning | Cannot use vendor name in customer-facing products |
| Attribution | Info | Must credit in docs — low risk but still an obligation |
| Warranty disclaimer | Info | Standard, but important to document for vendor risk register |
| Export control | Warning/Critical | Cryptographic software may have export restrictions |
| Data processing | Warning | License silent on data — separate DPA may be needed |

---

## Deployment architecture

```
[Bank server]
│
├── Docker network: license-radar-net
│   ├── app (Flask + gunicorn, port 5000)
│   │   ├── mounts: ./data (SQLite + ChromaDB)
│   │   └── mounts: ./uploads (license files)
│   └── ollama (port 11434, internal only)
│       └── mounts: ./ollama-models
│
└── Reverse proxy (nginx or bank's existing proxy)
    └── forwards HTTPS → app:5000
```

Ollama port is NOT exposed to the host network — only accessible within
the Docker network by the app container. This prevents direct LLM access
from outside.

---

## Upgrade path (post v1)

These are deliberately excluded from v1 but are natural next steps:

1. **Bulk import** — CSV upload for initial application/component population
2. **Package manager scanning** — parse package.json, pom.xml, requirements.txt to auto-detect components
3. **Export reports** — PDF/Excel compliance report per team
4. **Email alerts** — notify team leads when a new critical clause is detected
5. **PostgreSQL migration** — if concurrent users grow or backup/replication needed
6. **LDAP/AD integration** — for SSO with existing bank directory
7. **Scheduled re-analysis** — flag licenses for periodic review when they expire or update

---

## Server sizing guide

| RAM | Recommended model | Expected analysis time per license |
|-----|------------------|-----------------------------------|
| 8 GB | qwen2.5:7b-instruct-q4_K_M | 20-40 seconds |
| 16 GB | qwen2.5:14b-instruct-q4_K_M | 40-90 seconds |
| 32 GB | qwen2.5:14b-instruct-q8_0 | 60-120 seconds (better quality) |

Analysis runs in batch (admin-triggered), so speed is not critical.
The application itself (Flask + SQLite) uses under 200MB RAM.
ChromaDB embedded adds ~100MB for hundreds of documents.
