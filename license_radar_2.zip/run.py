import os
import bcrypt
from app import create_app
from app.models import init_db, User, Team, Settings
from app import Session
from config import Config
from sqlalchemy import inspect

def seed_admin():
    session = Session()
    existing_users = session.query(User).count()
    
    if existing_users == 0:
        print("No users found. Seeding initial admin account...")
        
        pw_hash = bcrypt.hashpw(
            Config.INITIAL_ADMIN_PASSWORD.encode('utf-8'), 
            bcrypt.gensalt()
        ).decode('utf-8')
        
        admin = User(
            username=Config.INITIAL_ADMIN_USERNAME,
            email=Config.INITIAL_ADMIN_EMAIL,
            password_hash=pw_hash,
            role='admin',
            is_active=True
        )
        session.add(admin)
        session.commit()
        print(f"Admin user created: {Config.INITIAL_ADMIN_USERNAME}")
    
    session.close()

def ensure_settings_table():
    """Ensure Settings table exists (for existing databases)."""
    from app.models import Base
    from app import engine
    inspector = inspect(engine)
    if 'settings' not in inspector.get_table_names():
        print("Creating Settings table...")
        Base.metadata.create_all(engine)
        print("Settings table created.")

os.makedirs(os.path.dirname(Config.DATABASE_PATH) or '.', exist_ok=True)
os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

init_db()
ensure_settings_table()
print("Database initialized.")

seed_admin()

app = create_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=Config.DEBUG)