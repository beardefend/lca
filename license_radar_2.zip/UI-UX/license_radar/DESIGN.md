---
name: License Radar
colors:
  surface: '#f9f9ff'
  surface-dim: '#d8d9e3'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3fd'
  surface-container: '#ecedf7'
  surface-container-high: '#e6e7f2'
  surface-container-highest: '#e1e2ec'
  on-surface: '#191b23'
  on-surface-variant: '#424754'
  inverse-surface: '#2e3038'
  inverse-on-surface: '#eff0fa'
  outline: '#727785'
  outline-variant: '#c2c6d6'
  surface-tint: '#005ac2'
  primary: '#0058be'
  on-primary: '#ffffff'
  primary-container: '#2170e4'
  on-primary-container: '#fefcff'
  inverse-primary: '#adc6ff'
  secondary: '#5c5e65'
  on-secondary: '#ffffff'
  secondary-container: '#dedfe8'
  on-secondary-container: '#60626a'
  tertiary: '#924700'
  on-tertiary: '#ffffff'
  tertiary-container: '#b75b00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#e1e2ea'
  secondary-fixed-dim: '#c4c6ce'
  on-secondary-fixed: '#191c22'
  on-secondary-fixed-variant: '#44474d'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#f9f9ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ec'
typography:
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  table-data:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '450'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  sidebar_width: 240px
  container_padding: 32px
  card_gap: 24px
  inline_gap: 12px
  stack_gap: 16px
  base_unit: 8px
---

## Brand & Style
The design system is engineered for the high-stakes environment of institutional banking. The brand personality is authoritative, systematic, and ultra-reliable. It prioritizes clarity over decoration to reduce cognitive load during complex auditing tasks.

The style follows a **Corporate Minimalist** movement. It utilizes a flat design language with a strict adherence to a grid, emphasizing structural integrity and data density. By stripping away gradients and expressive ornaments, the UI remains a functional tool that recedes into the background, allowing the compliance data to take center stage.

## Colors
The color palette is architected for functional signaling. The **Primary Blue** (#3b82f6) acts as the interactive driver, reserved for primary actions and navigational focus. The **Sidebar Dark** (#1a1d23) provides a grounding anchor, separating global navigation from the workspace.

The compliance palette uses high-contrast semantic colors to ensure immediate status recognition. All status colors must meet WCAG AA contrast ratios against white surfaces. Neutral grays are used for structural elements (borders and inactive states) to maintain the minimalist aesthetic without introducing visual noise.

## Typography
This design system utilizes **Inter** exclusively to leverage its exceptional legibility in data-heavy interfaces. The typographic scale is compact to accommodate dense information without sacrificing readability.

- **Headlines:** Use Semi-Bold (600) for clear section identification.
- **Labels:** Form labels and table headers use a smaller, uppercase treatment or bold weight to differentiate from input data.
- **Numerical Data:** Use tabular figures where possible to ensure alignment in columns and lists.

## Layout & Spacing
The layout uses a **Fixed-Fluid Hybrid** model. A permanent 240px sidebar stays fixed to the left viewport, while the main content area occupies the remaining width with a maximum container cap of 1440px to prevent excessive line lengths.

Spacing follows an 8px rhythmic grid. Internal card padding is set to 24px (3 units) to provide breathable gutters between data points, while form elements use 16px (2 units) vertical stacking to maintain a tight association between labels and inputs.

## Elevation & Depth
Depth is conveyed through **Low-Contrast Outlines** and subtle environmental shadows. The design avoids heavy elevation to maintain its minimalist corporate profile.

- **Level 0 (Canvas):** The background (#f4f6f9) serves as the lowest layer.
- **Level 1 (Surface):** Cards and main containers use white (#ffffff) with a 1px border (#e2e8f0) and a soft, diffused shadow (`0 1px 2px 0 rgba(0, 0, 0, 0.05)`).
- **Level 2 (Interaction):** Hover states on interactive rows or buttons should not increase elevation, but instead shift background color or border intensity.

## Shapes
The design system employs a **Rounded** shape language to soften the corporate aesthetic and make the interface more approachable. 

- **Containers:** All cards and modal surfaces use an 8px radius.
- **Interactive Elements:** Buttons and inputs use a slightly tighter 6px radius for a more precise, technical feel.
- **Status Pills:** Badges for compliance status utilize a full "pill" radius (9999px) to distinguish them instantly from rectangular data cells.

## Components

### Navigation Sidebar
A fixed 240px dark surface (#1a1d23). Nav items should use an "active indicator" (a 4px vertical primary blue bar) on the left edge. Icons are line-weight, 20px, and low-opacity white when inactive.

### Data Tables
Zebra-striped for readability. Alternate rows use #f8fafc. Headers are sticky, utilizing the uppercase label typography with a subtle bottom border. Row height is fixed at 48px to maintain density.

### Status Badges
Pill-shaped with a subtle background tint (10-15% opacity) and high-contrast text using the defined compliance colors. No borders on badges.

### Cards & Inputs
Cards must have a 1px solid border (#e2e8f0). Form inputs feature labels positioned directly above the field with a 4px gap. Input fields use a white background, 1px border, and a 2px primary blue outline on focus.

### Buttons
- **Primary:** Solid #3b82f6 with white text.
- **Secondary:** White background with #e2e8f0 border and dark text.
- **Destructive:** Solid #ef4444 for critical compliance overrides.