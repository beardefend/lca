# OpenCode Build Prompt — License Radar

Use the following prompt as your first message to OpenCode (MiniMax 2.5):

---

## PROMPT

You are building a complete, production-ready web application called **License Radar**.
Read the full specification in `SPEC.md` before writing a single line of code.
Follow every instruction in the spec exactly. Do not add features not listed.
Do not use React, Vue, or any JS framework. Do not use PostgreSQL. Do not use Redis.

### Build order — follow this sequence strictly:

**Phase 1 — Project scaffold**
1. Create the full directory structure as defined in SPEC.md
2. Create `requirements.txt` with all dependencies pinned to specific versions
3. Create `config.py` that reads all values from `.env` using python-dotenv
4. Create `.env.example` with all variables documented (no real secrets)
5. Create `app/__init__.py` with Flask app factory, register all extensions

**Phase 2 — Database models**
6. Create `app/models.py` with ALL models: User, Team, Application, Component, License, Clause, AuditLog
7. Create `run.py` with startup logic: db.create_all(), seed initial admin from .env if no users exist

**Phase 3 — Auth**
8. Create `app/routes/auth.py`: login (with Flask-Limiter), logout, change-password
9. Create auth templates: `templates/auth/login.html`, `templates/auth/change_password.html`
10. Create `templates/base.html` with sidebar navigation, flash messages, CSRF meta tag

**Phase 4 — Core routes**
11. Create `app/routes/dashboard.py` with risk summary and application table
12. Create `app/routes/applications.py` with full CRUD for applications and components
13. Create `app/routes/licenses.py` with upload and clause display
14. Create all corresponding Jinja2 templates

**Phase 5 — Admin routes**
15. Create `app/routes/admin.py` with user management, team management
16. Create admin templates

**Phase 6 — AI services**
17. Create `app/services/clause_service.py` with the clause taxonomy (9 types, risk levels)
18. Create `app/services/ai_service.py` that calls Ollama REST API, sends license text, returns structured clause JSON
19. Create `app/services/rag_service.py` with ChromaDB embed and query functions
20. Wire the research console at /admin/research

**Phase 7 — Styling**
21. Create `app/static/css/main.css` — full stylesheet, dark sidebar, clean content area, Inter font fallback to system-ui, all CSS variables defined, responsive sidebar collapse
22. Create `app/static/js/main.js` — minimal vanilla JS only: sidebar toggle, confirm dialogs, filter form auto-submit on dropdown change

**Phase 8 — Docker**
23. Create `Dockerfile` for the Flask app
24. Create `docker-compose.yml` with app + ollama services, volume mounts for data/ uploads/ ollama-models/
25. Create `docker-entrypoint.sh` that runs db init, seeds admin, starts gunicorn

### Hard rules — never violate these:

- Every POST route must validate CSRF token via Flask-WTF `@csrf.protect` or `form.validate_on_submit()`
- Every route except /auth/login must have `@login_required`
- Every admin route must check `if current_user.role != 'admin': abort(403)`
- Viewer queryset must be filtered: `if current_user.role == 'viewer' and current_user.team_id: query = query.filter_by(team_id=current_user.team_id)`
- File uploads: check extension against whitelist, check MIME type with python-magic, rename to `uuid4() + extension`, save to UPLOAD_FOLDER from config
- All DB queries through SQLAlchemy ORM — zero raw SQL f-strings
- All secrets from `config.py` which reads `.env` — zero hardcoded values
- Write an AuditLog entry for every state-changing action
- No mention of "AI", "LLM", "Ollama", "model", or "generated" anywhere in viewer-facing templates
- The "Run Analysis" button and /admin/research route must only render/be accessible when `current_user.role == 'admin'`

### AI service contract:

`ai_service.py` must send this prompt to Ollama and parse the JSON response:

```
System: You are a software license analyst. Extract all legally significant clauses
from the license text provided. Return ONLY valid JSON, no explanation, no markdown.

User: Analyze this license text and extract clauses as JSON:

{license_text}

Return this exact JSON structure:
{
  "license_name": "string",
  "spdx_id": "string or null",
  "clauses": [
    {
      "clause_type": "one of: copyleft|network_use|patent|commercial_restriction|trademark|attribution|warranty_liability|export_control|data_processing",
      "clause_title": "short title",
      "clause_text": "exact excerpt from license",
      "risk_level": "one of: critical|warning|info",
      "deployment_scope": "one of: internal|external|both",
      "ai_explanation": "plain English explanation of what this means for a bank"
    }
  ]
}
```

Parse the JSON response, validate each clause has required fields, save to DB.
If Ollama returns malformed JSON, log the error, set license analysis_status = "failed", do not crash.

### RAG service contract:

`rag_service.py` must:
- On license analysis completion: embed the license text into ChromaDB collection "licenses" with metadata `{license_id, component_name, application_name, team_name}`
- On query: embed the query, retrieve top 5 chunks, build context string, send to Ollama with prompt: "You are a license compliance analyst for a bank. Using only the license information provided, answer the question. If the answer is not in the provided context, say so.\n\nContext:\n{context}\n\nQuestion: {query}"
- Return the answer text and list of source references

### Template conventions:

- Every template extends base.html
- Flash messages displayed at top of content area: green for success, red for error, amber for warning
- Tables must have a empty-state row ("No applications found") when result set is empty
- All forms must include `{{ form.hidden_tag() }}` for CSRF
- Risk level pills: `<span class="pill pill--critical">Critical</span>` etc.
- Navigation active state: compare `request.endpoint` to highlight current nav item
- Page titles follow pattern: "Applications — License Radar"

### After completing all phases:

Review the entire codebase and confirm:
1. No hardcoded secrets
2. All routes protected
3. CSRF on all forms
4. File upload validation complete
5. AuditLog writes in place
6. No AI terminology in viewer templates
7. Docker Compose tested mentally (correct service names, ports, volumes)

Then output a `SETUP.md` file with step-by-step instructions to deploy.

---

## Tips for working with OpenCode / MiniMax 2.5

- If the model starts building before finishing the spec, stop it and remind it to finish reading SPEC.md first
- If it skips a phase, explicitly say "You are on Phase N, complete Phase N fully before moving to Phase N+1"
- After Phase 2, ask it to show you models.py and verify all models match the spec before continuing
- After Phase 7, ask it to show you the CSS variables and confirm Inter is loaded from local file
- If it uses React or PostgreSQL at any point, stop it immediately and redirect
- MiniMax 2.5 can handle long context well — paste the full SPEC.md content in your first message alongside this prompt
