# SOP: Exporting and Transferring a Custom Docker Image

**Purpose:** To capture the state of a modified running container and migrate it to an offline or secondary machine.

---

### **Phase 1: Source Machine (Capture & Package)**
Perform these steps on the computer where the custom container is currently running.

1.  **Identify the Container:**
    List running containers to find the **Container ID** or **Name**.
    ```bash
    docker ps
    ```
2.  **Commit Changes:**
    Create a new image from the running container's current state.
    ```bash
    # Replace <CONTAINER_ID> with your actual ID from step 1
    docker commit <CONTAINER_ID> custom-ollama:v1
    ```
3.  **Export to Tarball:**
    Save the newly created image into a portable compressed archive.
    ```bash
    docker save -o custom-ollama-v1.tar custom-ollama:v1
    ```

---

### **Phase 2: Data Transfer**
1.  **Move the File:** 
    Transfer `custom-ollama-v1.tar` to the destination machine via USB, SCP, or network share.

---

### **Phase 3: Destination Machine (Load & Launch)**
Perform these steps on the new computer.

1.  **Load the Image:**
    Import the tarball into the local Docker engine.
    ```bash
    docker load -i custom-ollama-v1.tar
    ```
2.  **Verify Import:**
    Ensure the image appears in the local list.
    ```bash
    docker images
    ```
3.  **Launch the Container:**
    Run the container using the imported image.
    ```bash
    docker run -d \
      --name ollama-service \
      -p 11434:11434 \
      custom-ollama:v1
    ```

---

### **Critical Troubleshooting Notes**
*   **Volumes:** Docker `save` does **not** include data stored in external volumes. If your models are in a volume, move that directory manually.
*   **Architecture:** The image must match the CPU architecture (e.g., AMD64 vs ARM64).
*   **Permissions:** Use `sudo` if you encounter permission errors.